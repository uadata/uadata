<?php

require_once '/var/www/mysqly.php';



function title() {
  $site = 'Український Дата Хаб';
  $title = 'Втрати армії РФ, втрати України та інша статистика з України - ' . $site;
  
  if ( $_GET['q'] ) {
    $title = 'Дані "' . h($_GET['q']) . '" - ' . $site;
  }
  else if ( preg_match('/^\/([^\/]+)$/', endpoint()) ) {
    if ( $hub = mysqly::hubs_(['url' => trim(endpoint(), '/')]) ) {
      $title = h($hub['title']);
    }
  }
  else if ( preg_match('/^\/(.+)\/(.+)\/(.+)$/', endpoint()) && !phpy::is_com_file(endpoint()) ) {
    $urls = explode('/', endpoint());
    $dt = urldecode($urls[3]);
    
    if ( $ent = entity_by_endpoint('/' . $urls[1] . '/' . $urls[2]) ) {
      $date_title = $ent['class'] == 'years' ? date('Y рік', strtotime($dt)) : human_date($dt, true);
      $on = ($ent['type'] == 'gauge' ? 'на' : 'за');
      $title = h($ent['long_title'] ?: $ent['title']) . ' ' . $on . ' ' . $date_title . ' - ' . $site;
    }
  }
  else if ( preg_match('/^\/(.+)\/(.+)$/', endpoint()) && !phpy::is_com_file(endpoint()) ) {
    if ( $ent = entity_by_endpoint(endpoint()) ) {
      if ( $ent['long_title'] ) {
        $title = h($ent['long_title']) . ' - ' . $site;
      }
      else {
        $title = h($ent['title'] . ' / ' . mysqly::hubs_title($ent['hub_id'])) . ' - ' . $site;
      }
    }
  }
  else if ( endpoint() == '/' ) {
    # $title = h(mysqly::hubs_title(1)) . ' - ' . $site;
  }
  
  return $title;
}

function desktop_mob($d, $m) {
  return ['span.desktop' => $d, 'span.mob' => $m];
}

function nav() {
  $main = [
    'a' => ['Назад', 'attrs' => ['href' => '/']],
    'b' => '/'
  ];
  
  $nav = [];
  
  if ( endpoint() == '/manage/hub' ) {
    $nav[] = ['a' => ['Всі хаби', 'attrs' => ['href' => '/manage']]];
    $nav[] = ['b' => '/'];
    $nav[] = [mysqly::hubs_title($_GET['id'])];
  }
  else if ( endpoint() == '/manage/entity' ) {
    $ent = mysqly::entities_($_GET['id']);
    $nav[] = ['a' => ['Всі хаби', 'attrs' => ['href' => '/manage']]];
    $nav[] = ['b' => '/'];
    $nav[] = ['a' => [mysqly::hubs_title($ent['hub_id']), 'attrs' => ['href' => '/manage/hub?id=' . $ent['hub_id']]]];
    $nav[] = ['b' => '/'];
    $nav[] = [h($ent['title'])];
  }
  else if ( preg_match('/^\/([^\/]+)$/', endpoint()) ) {
    if ( $hub = mysqly::hubs_(['url' => trim(endpoint(), '/')]) ) {
      $nav[] = ['a' => ['Хаби', 'attrs' => ['href' => '/']]];
      $nav[] = ['b' => '/'];
      $nav[] = h($hub['title']);
    }
  }
  else if ( preg_match('/^\/(.+)\/(.+)\/(.+)$/', endpoint()) ) {
    $urls = explode('/', endpoint());
    $dt = urldecode($urls[3]);
    
    if ( $ent = entity_by_endpoint('/' . $urls[1] . '/' . $urls[2]) ) {
      $nav[] = ['a' => ['Хаби', 'attrs' => ['href' => '/']]];
      $nav[] = ['b' => '/'];
      $nav[] = ['a' => [
        mysqly::hubs_title($ent['hub_id']),
        'attrs' => ['href' => '/' . mysqly::hubs_url($ent['hub_id'])]
      ]];
      $nav[] = ['b' => '/'];
      $nav[] = ['a' => [
        $ent['title'],
        'attrs' => ['href' => entity_url($ent)]
      ]];
      
      $nav[] = ['b' => '/'];
      $nav[] = [ $ent['class'] == 'years' ? date('Y рік', strtotime($dt)) : human_date($dt, true) ];
    }
  }
  else if ( preg_match('/^\/(.+)\/(.+)$/', endpoint()) ) {
    if ( $ent = entity_by_endpoint(endpoint()) ) {
      $nav[] = ['a' => ['Хаби', 'attrs' => ['href' => '/']]];
      $nav[] = ['b' => '/'];
      $nav[] = ['a' => [
        mysqly::hubs_title($ent['hub_id']),
        'attrs' => ['href' => '/' . mysqly::hubs_url($ent['hub_id'])]
      ]];
      $nav[] = ['b' => '/'];
      $nav[] = [h($ent['title'])];
    }
  }
  else if ( $_GET['q'] ) {
    $nav[] = $main;
    $nav[] = ['h1' => 'Результати пошуку "' . h($_GET['q']) . '"'];
  }
  
  return ['span.nav' => $nav];
}

function form($html, $target, $action = '') {
  if ( !$action ) $action = endpoint();
  
  return [
    'form' => [
      'attrs' => [
        'method' => 'post', 'action' => $action,
        'onsubmit' => "stop_event(window.event); this.classList.add('load'); var f = this; com('{$target}', '{$action}', this, function() {
          remove_cls('.load', '.load');
        });"
      ],
      
      $html
    ],
  ];
}

function entity_data($id, $period = null, $params = []) {
  $ent = mysqly::entities_($id);
  
  if ( $ent['class'] == 'years' ) {
    $data = mysqly::fetch('SELECT YEAR(at) year, SUM(value) value FROM ref_data WHERE entity_id = :id AND status = :s GROUP BY year ORDER BY at ASC', [':id' => $ent['id'], ':s' => 'approved']);
    
    $list = [];
    foreach ( $data as $r ) {
      $list[] = ['at' => $r['year'].'-01-01 00:00:01', 'value' => $r['value']];
    }
    
    return $list;
  }
  
  $data = mysqly::fetch('ref_data', ['entity_id' => $ent['id'], 'status' => 'approved', 'order_by' => 'at ASC']);
  
  if ( $params['from'] && $params['to'] ) {
    foreach ( $data as $r ) {
      
      if ( (strtotime($r['at']) >= strtotime($params['from'])) && (strtotime($r['at']) <= strtotime($params['to'])) ) {
        $filtered_data[] = $r;
      }
    }
    
    $data = $filtered_data;
  }
  
  foreach ( $data as $r ) {
    $data_structured[date('Y-m-d', strtotime($r['at']))] = $r;
  }
  
  if ( $period == 'm' ) {
    $start = date('Y-m-d', strtotime($data[0]['at']));
    $end = date('Y-m-d', strtotime($data[count($data) - 1]['at']));
  }
  else {
    $start = date('Y-m-d', time() - 60*60*24*7*( $period ?: 2 ));
    $end = date('Y-m-d');
  }
  
  $now = $start;
  $normalized = [];
  
  while ( $now <= $end ) {
    $found = $data_structured[$now];
    $normalized[] = $found ?: ['at' => $now, 'value' => '0', 'undefined' => true];
    $now = date('Y-m-d', strtotime($now . ' +1 day'));
  }
  
  return $normalized;
}



function search_entities() {
  if ( $_GET['q'] ) {
    return mysqly::fetch('SELECT * FROM entities WHERE title LIKE :q', [':q' => '%' . $_GET['q'] . '%']);
  }
  else {
    return mysqly::fetch('entities');
  }
}

function entity_url($e) {
  return '/' . mysqly::hubs_url($e['hub_id']) . '/' . $e['url'];
}

function entity_by_endpoint($endpoint) {
  if ( strpos($endpoint, ':') ) {
    list($endpoint, $period) = explode(':', $endpoint);
  }
  
  $uris = explode('/', trim($endpoint, '/'));
  $hub = mysqly::hubs_(['url' => $uris[0]]);
  $ent = mysqly::entities_(['url' => $uris[1], 'hub_id' => $hub['id']]);
  
  return $ent;
}

function current_entity_val($id) {
  $ent = mysqly::entities_($id);
  
  if ( $ent['class'] == 'table' ) {
    $prop = mysqly::array('SELECT DISTINCT property FROM tables WHERE entity_id = :id', [':id' => $ent['id']])[0];
    return mysqly::fetch('SELECT SUM(value) s FROM tables WHERE entity_id = :id AND property = :p', [
      ':id' => $ent['id'], ':p' => $prop
    ])[0]['s'];
  }
  
  if ( $ent['type'] == 'counter' ) {
    return mysqly::fetch('SELECT SUM(value) t FROM ref_data WHERE entity_id = :id', [':id' => $id])[0]['t'];
  }
  
  return mysqly::fetch('ref_data', ['entity_id' => $id, 'order_by' => 'at desc limit 1'])[0]['value'];
}

function current_entity_src($id) {
  return mysqly::fetch('SELECT ref_url FROM ref_data WHERE entity_id = :id ORDER BY at DESC LIMIT 1', [':id' => $id])[0]['ref_url'];
}

function latest_entity_entry($id) {
  return mysqly::fetch('ref_data', ['entity_id' => $id, 'order_by' => 'at desc limit 1'])[0];
}

function from_ua_month($title) {
  $months = [
    '01' => 'січ', '02' => 'лют', '03' => 'берез', '04' => 'квіт',
    '05' => 'трав', '06' => 'черв', '07' => 'лип', '08' => 'серп',
    '09' => 'верес', '10' => 'жовт', '11' => 'лист', '12' => 'груд',
  ];
  
  foreach ( $months as $m => $n ) {
    if ( strpos($title, $n) !== false ) {
      return $m;
    }
  }
}

function human_month($m, $direct = false) {
  $months = [
    '01' => 'січня', '02' => 'лютого', '03' => 'березня', '04' => 'квітня',
    '05' => 'травня', '06' => 'червня', '07' => 'липня', '08' => 'серпня',
    '09' => 'вересня', '10' => 'жовтня', '11' => 'листопада', '12' => 'грудня',
  ];
  
  $months_direct = [
    '01' => 'січень', '02' => 'лютий', '03' => 'березень', '04' => 'квітень',
    '05' => 'травень', '06' => 'червень', '07' => 'липень', '08' => 'серпень',
    '09' => 'вересень', '10' => 'жовтень', '11' => 'листопад', '12' => 'грудень',
  ];
  
  return $direct ? $months_direct[$m] : $months[$m];
}

function human_date($at, $year = false) {
  return date('j', strtotime($at)) . ' ' . human_month(date('m', strtotime($at))) . 
         ($year ? (' ' . date('Y', strtotime($at))) : '');
}

function updated($ent_id) {
  $last = latest_entity_entry($ent_id);
  $ts = strtotime($last['at']);
  
  if ( !$ts ) {
    return '';
  }
  
  if ( date('Y-m-d', $ts) == date('Y-m-d') ) {
    $text = ['span.updated.today' =>  'оновлено сьогодні'];
  }
  else if ( date('Y-m-d', $ts) == date('Y-m-d', strtotime('yesterday')) ) {
    $text = ['span.updated.yesterday' =>  'оновлено вчора'];
  }
  else {
    if ( $ts < time() - 60*60*24*30*12 ) {
      $text = ['span.updated' =>  'оновлено в ' . date('Y', $ts)];
    }
    else {
      $text = ['span.updated' =>  'оновлено ' . date('d.m Y', $ts)];
    }
  }
  
  return $text;
}

function word_form($n, $w1, $w2, $w3) {
  $last_figure = (string)$n;
  $last_figure = $last_figure[strlen($last_figure) - 1];
  
  if ( $last_figure == 1 ) {
    return $w1;
  }
  else if ( ($last_figure >= 2 && $last_figure <= 4) && !in_array($n, [11, 12, 13, 14]) ) {
    return $w2;
  }
  else {
    return $w3;
  }
  
  return $last_figure;
}

function v($num) {
  return number_format($num, 0, '.', ' ');
}


function parse_import($regex, $raw) {
  preg_match_all($regex, $raw, $m);
  
  $matched = [];
  foreach ( $m[1] as $i => $v ) {
    foreach ( $m as $r => $ms ) if ( $r > 0 ) {
      $matched[$i][$r] = $ms[$i];
    }
  }
  
  return $matched;
}


