<?php

require_once __DIR__ . '/../../lib/helpers.php';

$url = 'https://index.minfin.com.ua/ua/finance/budget/cons/expense/';
$years = range(2015, date('Y') - 1);

foreach ( $years as $year ) {
  $year_url = $url . $year . '/';
  echo $year_url . "\n";
  
  $html = file_get_contents($year_url);
  
  $m = [];
  preg_match_all('/<td class=\'thinpaddingcell\'>.+?;([0-9.]+)<\/td>.+?<\/span>[^<]+<\/td><td align=\'right\' class=\'small\'>([0-9,]+)<\/td><\/tr>/misu', $html, $m);
  
  foreach ( $m[1] as $index => $dt ) {
    if ( $ts = strtotime($dt) ) {
      $v = str_replace(',', '.', trim($m[2][$index])) * 1000 * 1000;
      
      mysqly::insert('tables_ts', [
        'entity_id' => 34,
        'property' => 'грн',
        'at' => date('Y-m-d H:i:s', $ts),
        'value' => $v
      ]);
    }
  }
  
  
  $m = [];
  preg_match_all('/style=\'padding-left:1rem\'>([^<]+)<\/td>.+?<td align=\'right\'>([0-9,]+)<\/td>/misu', $html, $m);
  
  foreach ( $m[1] as $index => $object ) {
    $object = trim($object);
    $v = str_replace(',', '.', trim($m[2][$index])) * 1000 * 1000;
    
    mysqly::insert('tables_ts', [
      'entity_id' => 34,
      'object' => $object,
      'property' => 'грн',
      'at' => "{$year}-01-01 00:00:00",
      'value' => $v
    ]);
  }
  
  sleep(mt_rand(1, 5));
  
  echo '.';
}

echo "\n";