<?php

require_once __DIR__ . '/../../lib/helpers.php';

$csv = '/var/www/data/rub.csv';
$ent_id = 33;


$f = fopen($csv, 'r');

while ( $row = fgetcsv($f) ) {
  if ( !strtotime($row[0]) ) continue;
  
  $at = date('Y-m-d', strtotime($row[0]));
  $val = $row[6] / $row[4];
  
  if ( $at && $val ) {
    mysqly::insert('ref_data', [
      'ref_url' => 'https://bank.gov.ua/ua/markets/exchangerates',
      'entity_id' => $ent_id,
      'value' => $val,
      'at' => $at,
      'status' => 'approved'
    ]);
    echo '.';
  }
}

fclose($f);
echo "\n";