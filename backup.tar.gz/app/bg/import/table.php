<?php

require_once __DIR__ . '/../../lib/helpers.php';

$text = "Країна	Фінансові втрати
СРСР	600
США	350
Велика Британія	150
Франція	100
Німеччина	300
Італія	50
Японія	100
Інші країни	350";

$ent_id = 30;

foreach ( explode("\n", $text) as $i => $line ) {
  $row = explode("\t", $line);
  
  if ( $i == 0 ) {
    $head = $row;
    continue;
  }
  
  foreach ( $row as $r => $v ) {
    echo '.';

    if ( $r == 0 ) {
      $object = $v;
      continue;
    }
    
    if ( $object == 'ВСЬОГО' ) { 
      continue 2;
    }
    
    $v = str_replace(' ', '', $v);
    if ( !$v ) {
      continue;
    }
    
    mysqly::insert('tables', [
      'entity_id' => $ent_id,
      'object' => $object,
      'property' => $head[$r],
      'value' => $v
    ]);
  }
}

