<?php

require_once __DIR__ . '/../../lib/helpers.php';

$table = [
  preg_split('/\s+/', '1979	1980	1981	1982	1983	1984	1985	1986	1987	1988	1989'),
  preg_split('/\s+/', '3	39	22	33	28	49	49	44	49	14	3')
];

$entity_id = 27;
$ref_url = 'https://ru.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D0%BF%D0%BE%D1%82%D0%B5%D1%80%D1%8C_%D1%81%D0%BE%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B8%D1%85_%D0%B2%D0%B5%D1%80%D1%82%D0%BE%D0%BB%D1%91%D1%82%D0%BE%D0%B2_%D0%B2_%D0%90%D1%84%D0%B3%D0%B0%D0%BD%D1%81%D0%BA%D0%BE%D0%B9_%D0%B2%D0%BE%D0%B9%D0%BD%D0%B5';

foreach ( $table[0] as $i => $year ) {
  $v = $table[1][$i];
  
  mysqly::insert('ref_data', [
    'at' => date('Y-m-d H:i:s', mktime(00, 00, 00, 1, 1, $year)),
    'value' => $v,
    'entity_id' => $entity_id,
    'ref_url' => $ref_url,
    'status' => 'approved'
  ]);
}