<?php

require_once __DIR__ . '/../../lib/helpers.php';

$url = 'https://en.wikipedia.org/wiki/List_of_Soviet_aircraft_losses_during_the_Soviet%E2%80%93Afghan_War';
$ent_id = 19;


mysqly::remove('ref_data', [
  'entity_id' => $ent_id
]);


$c = curl_init($url);
curl_setopt_array($c, [
  CURLOPT_RETURNTRANSFER => true
]);
$html = curl_exec($c);
preg_match_all('/<h2><span class="mw-headline" id="([0-9]+)">(.+?)<\/ul>/misu', $html, $m);

foreach ( $m[2] as $i => $sub_html ) {
  $mm = [];
  preg_match_all('/<li>(.+?)\–/', $sub_html, $mm);
  
  foreach ( $mm[1] as $date ) {
    $date = str_replace('?', '1', $date);
    $ts = strtotime(trim($date));
    
    if ( !$ts ) {
      print_r($date);
      exit;
    }
    
    $dt = date('Y-m-d', $ts);
    $list[$dt] += 1;
  }
}



foreach ( $list as $date => $v ) {
  mysqly::insert('ref_data', [
    'entity_id' => $ent_id,
    'at' => $date . ' 00:00:01',
    'value' => $v,
    'ref_url' => $url,
    'status' => 'approved'
  ]);
}