<?php

function mb_ucfirst($string, $encoding = 'utf8')
{
    $firstChar = mb_substr($string, 0, 1, $encoding);
    $then = mb_substr($string, 1, null, $encoding);
    return mb_strtoupper($firstChar, $encoding) . $then;
}

require_once __DIR__ . '/../../lib/helpers.php';

chdir(__DIR__);

$ip = gethostbyname('unmetered.residential.proxyrack.net');
$conf = "tcp_read_time_out 15000
tcp_connect_time_out 8000

[ProxyList]
socks5	{$ip}	222	iotechnologies	2629bd-711a83-b52ec8-1f61c2-a31bf1
";
file_put_contents(__DIR__ . '/proxychains.conf', $conf);



$titles = [
  'лікар', 'водій', 'директор', 'брокер',
  'адміністратор', 'асистент', 'будівельник', 'маркетолог', 'бухгалтер',
  'прибиральник', 'інженер', 'менеджер з продажів', 'редактор', 'юрист',
  'логіст', 'оператор', 'охоронець', 'вчитель',
  'програміст', 'дизайнер', 'фінансист', 'економіст',
  'тестувальник', 'офіс менеджер'
];

$title_stats = [];

foreach ( [] as $i => $title ) {
  $url = 'https://ua.jooble.org/SearchResult?=україна&ukw=' . urlencode($title);
  
  echo mb_ucfirst($title) . ': ';
  
  $html = null;
  $attempts = 5;
  do {
    $o = [];
    exec('proxychains google-chrome --headless --dump-dom "' . $url . '" 2>/dev/null', $o);
    $html = str_replace('&nbsp;', ' ', implode($o));
    
    if ( !$html ) {
      echo '.';
      sleep(30);
    }
  } while ( !$html && (--$attempts > 0) );
  
  if ( !$html ) {
    die('  FAIL getting html' . "\n");
  }
  
  
  preg_match('/class="_22VJWN">([0-9 ]+)[^<]+?</misu', $html, $m);
  $total = trim(str_replace([' '], '', $m[1]));
  
  if ( $total ) {
    echo ' ' . $total . "\n";
  }
  else {
    echo('  FAIL extracting data' . "\n");
    continue;
  }
  
  mysqly::insert('tables_ts', [
    'entity_id' => 36,
    'object' => mb_ucfirst($title),
    'at' => date('Y-m-d H:i:s'),
    'value' => $total
  ]);
}



$geo = [
  'Україна', 'Запоріжжя', 'Дніпро',
  'Кривий Ріг', 'Тернопіль', 'Київ', 'Харьків', 'Львів', 'Одеса',
];

$geo_stats = [];

foreach ( $geo as $i => $location ) {
  $url = 'https://ua.jooble.org/SearchResult?rgns=' . urlencode($location);
  
  echo $location . ': ';
  
  $html = null;
  $attempts = 5;
  do {
    $o = [];
    exec('proxychains google-chrome --headless --dump-dom "' . $url . '" 2>/dev/null', $o);
    $html = str_replace('&nbsp;', ' ', implode($o));
    
    if ( !$html ) {
      echo '.';
      sleep(30);
    }
  } while ( !$html && (--$attempts > 0) );
  
  if ( !$html ) {
    die('  FAIL getting html' . "\n");
  }
  
  
  preg_match('/class="_22VJWN">([0-9 ]+)[^<]+?</misu', $html, $m);
  $total = trim(str_replace([' '], '', $m[1]));
  
  if ( $total ) {
    echo ' ' . $total . "\n";
  }
  else {
    echo('  FAIL extracting data' . "\n");
    continue;
  }
  
  
  $ms = [];
  $sal = [];
  preg_match_all('/<p class="jNebTl">(.+?) грн</misu', $html, $ms);
  foreach ( $ms[1] as $raw ) {
    list($from, $to) = explode(' - ', trim($raw));
    $from = trim(str_replace(' ', '', $from));
    $to = trim(str_replace(' ', '', $to));
    
    if ( is_numeric($from) ) {
      $sal[] = ($from + (is_numeric($to) ? $to : $from)) / 2;
    }
  }
  
  sort($sal);
  $median_salary = $sal[ceil(count($sal) / 2)];
  echo '  median salary: ' . $median_salary . "\n";
  
  
  $mr = [];
  preg_match_all('/="_remoteJobLabel"/misu', $html, $mr);
  $remote = count($mr[0]);
  
  $mr = [];
  preg_match_all('/<article/misu', $html, $mr);
  $all = count($mr[0]);
  echo '  remote: ' . round($remote*100/$all) . '%' . "\n";
  
  
  $stats = [
    'total' => $total,
    'salary' => $median_salary,
    'remote' => round($remote*100/$all)
  ];
  
  mysqly::insert('tables_ts', [
    'entity_id' => 35,
    'object' => $location == 'Україна' ? NULL : $location,
    'at' => date('Y-m-d H:i:s'),
    'value' => $stats['total']
  ]);
  
  if ( $location == 'Україна' ) {
    mysqly::insert('tables_ts', [
      'entity_id' => 36,
      'object' => $location == 'Україна' ? NULL : $location,
      'at' => date('Y-m-d H:i:s'),
      'value' => $stats['total']
    ]);
  }
  
  mysqly::insert('tables_ts', [
    'entity_id' => 37,
    'object' => $location == 'Україна' ? NULL : $location,
    'at' => date('Y-m-d H:i:s'),
    'value' => $stats['salary']
  ]);
  
  mysqly::insert('tables_ts', [
    'entity_id' => 38,
    'object' => $location == 'Україна' ? NULL : $location,
    'at' => date('Y-m-d H:i:s'),
    'value' => $stats['remote']
  ]);
}
