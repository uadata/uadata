<?php

require_once __DIR__ . '/../../lib/helpers.php';

foreach ( mysqly::fetch('tables_ts') as $row ) {
  $ts = strtotime($row['at']);
  $at = date('Y-m-d', $ts);
  $value = $row['value'];
  
  $usd = mysqly::fetch('SELECT avg(value) FROM ref_data WHERE entity_id = 31 AND year(at) = year(:date)', [':date' => $at])[0];
  $usd = array_shift($usd);
  
  $value_usd = round($value/$usd);
  echo $at . ': ' . "\t" . number_format($value, 0, '.', ' ') . "\t\t" . number_format($value_usd, 0, '.', ' ') . "\n";
  mysqly::insert('tables_ts', [
    'entity_id' => 34,
    'object' => $row['object'] ?: null,
    'property' => 'usd',
    'at' => date('Y-m-d 00:00:00', $ts),
    'value' => $value_usd
  ]);
}