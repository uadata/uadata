<?php

require_once __DIR__ . '/../../lib/helpers.php';



# Korona total cases/deaths - full history
# "full" arguments should be supplied
if ( in_array('full', $argv) ) {
  @unlink('/tmp/who.csv');
  exec("wget 'https://covid19.who.int/WHO-COVID-19-global-data.csv' -O /tmp/who.csv");
  
  #mysqly::remove('ref_data', ['entity_id' => 22]);
  #mysqly::remove('ref_data', ['entity_id' => 23]);
  
  $f = fopen('/tmp/who.csv', 'r');
  while ( $row = fgetcsv($f) ) {
    if ( $row[1] == 'UA' ) {
      $at = date('Y-m-d H:i:s', strtotime($row[0]));
      
      if ( mysqly::fetch('ref_data', ['at' => $at, 'entity_id' => 22]) ) continue;
      mysqly::insert('ref_data', [
        'at' => $at,
        'value' => $row[4],
        'entity_id' => 22,
        'ref_url' => 'https://covid19.who.int/data',
        'status' => 'approved'
      ]);
      
      if ( mysqly::fetch('ref_data', ['at' => $at, 'entity_id' => 23]) ) continue;
      mysqly::insert('ref_data', [
        'at' => $at,
        'value' => $row[6],
        'entity_id' => 23,
        'ref_url' => 'https://covid19.who.int/data',
        'status' => 'approved'
      ]);
      
      echo '.';
    }
  }
  
  fclose($f);
}
else {



  # Korona last day cases/deaths
  @unlink('/tmp/who.csv');
  $o = [];
  exec("curl -silent -I 'https://covid19.who.int/WHO-COVID-19-global-table-data.csv'", $o);
  foreach ( $o as $l ) {
    list($h, $v) = explode(': ', trim($l));
    if ( $h == 'last-modified' ) {
      $updated = date('Y-m-d H:i:s', strtotime($v));
    }
  }
  
  if ( !$updated ) {
    die('Could not find "last-modified" header');
  }
  
  $at = date('Y-m-d 00:00:00', strtotime($updated . ' -1 day'));
  
  @unlink('/tmp/who.csv');
  exec("wget 'https://covid19.who.int/WHO-COVID-19-global-table-data.csv' -O /tmp/who.csv");
  
  $sh = '/tmp/' . md5(file_get_contents('/tmp/who.csv'));
  if ( !is_file($sh) ) {
  
    $f = fopen('/tmp/who.csv', 'r');
    while ( $row = fgetcsv($f) ) {
      if ( $row[0] == 'Ukraine' ) {
        $value = $row[6];
        
        if ( mysqly::fetch('ref_data', [ 'at' => $at, 'entity_id' => [22, 23] ]) ) {
          echo 'daily cases already updated' . "\n";
          continue;
        }
        
        mysqly::insert('ref_data', [
          'at' => $at,
          'value' => $row[6],
          'entity_id' => 22,
          'ref_url' => 'https://covid19.who.int/data',
          'status' => 'approved'
        ]);
        
        mysqly::insert('ref_data', [
          'at' => $at,
          'value' => $row[11],
          'entity_id' => 23,
          'ref_url' => 'https://covid19.who.int/data',
          'status' => 'approved'
        ]);
        
        echo 'daily cases data updated' . "\n";
      }
    }
    
    file_put_contents($sh, '1');
  }



  # Vacines stats
  @unlink('/tmp/who.csv');
  exec("curl --compressed 'https://covid19.who.int/who-data/vaccination-data.csv' -o /tmp/who.csv");
  
  $f = fopen('/tmp/who.csv', 'r');
  
  $sh = '/tmp/' . md5(file_get_contents('/tmp/who.csv'));
  if ( !is_file($sh) ) {
  
    while ( $row = fgetcsv($f) ) {
      if ( $row[0] == 'Ukraine' ) {
        $value = $row[6];
        $at = date('Y-m-d 00:00:00', strtotime($row[4]));
        
        if ( mysqly::fetch('ref_data', [ 'at' => $at, 'entity_id' => [24, 25, 26] ]) ) {
          echo 'vacines data already updated' . "\n";
          continue;
        }
        
        mysqly::insert('ref_data', [
          'at' => $at,
          'value' => $row[6],
          'entity_id' => 24,
          'ref_url' => 'https://covid19.who.int/data',
          'status' => 'approved'
        ]);
        
        mysqly::insert('ref_data', [
          'at' => $at,
          'value' => $row[9],
          'entity_id' => 25,
          'ref_url' => 'https://covid19.who.int/data',
          'status' => 'approved'
        ]);
        
        mysqly::insert('ref_data', [
          'at' => $at,
          'value' => $row[14],
          'entity_id' => 26,
          'ref_url' => 'https://covid19.who.int/data',
          'status' => 'approved'
        ]);
        
        echo 'vacines data updated' . "\n";
      }
    }
    
    file_put_contents($sh, '1');
  }
}
