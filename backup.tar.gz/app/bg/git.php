<?php

require_once __DIR__ . '/../lib/helpers.php';

$readme = '';

foreach ( mysqly::fetch('hubs') as $hub ) {
  $domain = 'https://uadata.net';
  $readme .= '# [' . $hub['title'] . '](' . $domain . '/' . $hub['url'] . ')' . "\n";
  
  $readme .= '[![Графік: ' . $hub['title'] . '](https://uadata.net/screen?' . round(time()/3600) . '&u=' . urlencode('/' . $hub['url']) . ')](' . $domain . '/' . $hub['url'] . ')' . "\n\n";
  
  $readme .= 'Оновлено **{%updated%}**' . "\n\n";
  
  foreach ( mysqly::fetch('entities', ['hub_id' => $hub['id']]) as $ent ) {
    $data = mysqly::fetch('SELECT * FROM ref_data WHERE entity_id = :id AND status = "approved" ORDER BY at DESC LIMIT 1', [':id' => $ent['id']])[0];
    $readme .= '- [' . $ent['title'] . '](' . $domain . entity_url($ent) . '): ' .
               $data['value'] .
               ' [історія](' . entity_url($ent) . '.md' .  ')' .
               "\n";
               
    $history_file = '/var/www/uadata/' . entity_url($ent) . '.md';
    if ( !is_dir(dirname($history_file)) ) {
      mkdir(dirname($history_file), 0755, true);
    }
    
    $history = '# ' . $ent['title'] . "\n" .
               '### Графік' . "\n" .
               '[ ![Графік: ' . $hub['title'] . ' / ' . $ent['title'] . '](https://uadata.net/screen?' . round(time()/3600) . '&u=' . urlencode(entity_url($ent)) . ') ](' . $domain . entity_url($ent) . ')' . "\n\n" . 
               '### Історія значень' . "\n" .
               '| Дата | Значення | Джерело |' . "\n" .
               '|---|---|---|' . "\n";
               
    foreach ( mysqly::fetch('SELECT * FROM ref_data WHERE entity_id = :id AND status = "approved" ORDER BY at DESC', [':id' => $ent['id']]) as $r ) {
      $history .= '| [' . date('Y-m-d', strtotime($r['at'])) . '](' . $domain . entity_url($ent) . '/' . urlencode($r['at']) . ') | ' . $r['value'] . ' | ' . '[відкрити](' . $r['ref_url'] . ')' . ' |' . "\n";
    }
    
    $api_response = file_get_contents($domain . entity_url($ent) . '.json');
    $api_response = substr($api_response, 0, 500) . '...';
    
    $history .= '### API' . "\n" .
                'Щоб отримати ці дані по API:' . "\n" .
                '```' . "\n" . 'curl ' . $domain . entity_url($ent) . '.json' . "\n" . '```' . "\n" .
                '#### Приклад відповіді ' . "\n" .
                '```' . "\n" . $api_response . "\n" . '```';
    
    file_put_contents($history_file, $history);
               
    $updated = max($data['at'], $updated);
  }
  
  $readme = str_replace('{%updated%}', $updated, $readme);
}

echo $readme;

file_put_contents('/var/www/uadata/README.md', $readme);