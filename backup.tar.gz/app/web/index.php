<?php


# Tracking
$uid = $_COOKIE['uid'] ?: uniqid();
setcookie('uid', $uid, time() + 60*10, '/');
if ( $_SERVER['REMOTE_ADDR'] != '93.75.252.211' ) {
  if ( stripos($_SERVER['REQUEST_URI'], '.json') !== false ) {
    file_get_contents("https://measury.io/t/uadata_api?uid={$uid}");
  }
  else if ( !$_SERVER['HTTP_USER_AGENT'] ||
            strpos($_SERVER['HTTP_USER_AGENT'], 'HeadlessChrome') ||
            (stripos($_SERVER['HTTP_USER_AGENT'], 'bot') !== false) ||
            (stripos($_SERVER['HTTP_USER_AGENT'], 'facebook') !== false)
          ) {
    file_get_contents("https://measury.io/t/uadata_bot?uid={$uid}");
  }
  else {
    error_log($_SERVER['HTTP_USER_AGENT']);
    file_get_contents("https://measury.io/t/uadata?uid={$uid}");
  }
  
}



# Run app
require_once '/var/www/phpy/build/phpy.php';
phpy([
  'config' => [
    'root' => __DIR__,
    'client-cache' => 35,
    'routes' => [
      '/^\/hubs\.json$/' => '/json',
      '/^\/([^\/]+)\.json$/' => '/hub/json',
      '/^\/([^\/]+)$/' => '/hub/index',
      '/^\/(.+)\/(.+)\/(.+)$/' => '/entity/date',
      '/^\/(.+)\/(.+)\.json$/' => '/entity/json',
      '/^\/(.+)\/(.+)$/' => '/entity/index',
    ]
  ]
]);
