<?php

require_once '/var/www/phpy/build/phpy.php';
phpy([
  'config' => [
    'root' => __DIR__,
    'client-cache' => 25,
    'routes' => [
      '/^\/([^\/]+)$/' => '/hub/index',
      '/^\/(.+)\/(.+)\/(.+)$/' => '/entity/date',
      '/^\/(.+)\/(.+)\.json$/' => '/entity/json',
      '/^\/(.+)\/(.+)$/' => '/entity/index',
    ]
  ]
]);
