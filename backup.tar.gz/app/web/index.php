<?php

require_once '/var/www/phpy/build/phpy.php';
phpy([
  'config' => [
    'root' => __DIR__,
    'client-cache' => 31,
    'routes' => [
      '/^\/hubs\.json$/' => '/json',
      '/^\/([^\/]+)\.json$/' => '/hub/json',
      '/^\/([^\/]+)$/' => '/hub/index',
      '/^\/(.+)\/(.+)\/(.+)$/' => '/entity/date',
      '/^\/(.+)\/(.+)\.json$/' => '/entity/json',
      '/^\/(.+)\/(.+)$/' => '/entity/index',
    ]
  ]
]);
