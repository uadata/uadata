<?php


# Tracking
$uid = $_COOKIE['uid'] ?: uniqid();
setcookie('uid', $uid, time() + 60*10, '/');
if ( $_SERVER['REMOTE_ADDR'] != '31.129.245.128' ) {
  if ( stripos($_SERVER['REQUEST_URI'], '.json') !== false ) {
    file_get_contents("https://measury.io/t/uadata_api?uid={$uid}");
  }
  else if ( !$_SERVER['HTTP_USER_AGENT'] || !$_SERVER['HTTP_REFERER'] ||
            strpos($_SERVER['HTTP_USER_AGENT'], 'HeadlessChrome') ||
            (stripos($_SERVER['HTTP_USER_AGENT'], 'bot') !== false) ||
            (stripos($_SERVER['HTTP_USER_AGENT'], 'facebook') !== false)
          ) {
    file_get_contents("https://measury.io/t/uadata_bot?uid={$uid}");
  }
  else {
    file_get_contents("https://measury.io/t/uadata?uid={$uid}&ref=" . urlencode($_SERVER['HTTP_REFERER']));
  }
  
}



# Run app
require_once '/var/www/phpy/build/phpy.php';
phpy([
  'config' => [
    'root' => __DIR__,
    'client-cache' => 36,
    'routes' => [
      '/^\/hubs\.json$/' => '/json',
      '/^\/([^\/]+)\.json$/' => '/hub/json',
      '/^\/([^\/]+)$/' => '/hub/index',
      '/^\/(.+)\/(.+)\/(.+)$/' => '/entity/date',
      '/^\/(.+)\/(.+)\.json$/' => '/entity/json',
      '/^\/(.+)\/(.+)$/' => '/entity/index',
    ]
  ]
]);
