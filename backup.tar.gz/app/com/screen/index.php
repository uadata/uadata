<?php

$u = urldecode($_GET['u']);
$f = '/tmp/screen.' . md5($u) . '.png';
$cmd = 'google-chrome --headless --disable-gpu --window-size=1600,950 --screenshot="' . $f . '" "https://uadata.net' . $u . '?screen=1"';
#exit;
if ( !is_file($f) || (filectime($f) < time() - 60*60) || filesize($f) < 10000 ) {
  exec($cmd);
}

header('Content-type: image/png');
echo file_get_contents($f);

exit;