<?php

if ( $_GET['q'] ) {
  return phpy(
    '/default/list',
    [
      'list' => mysqly::fetch(
        'SELECT e.* FROM entities e JOIN hubs h ON (h.id = e.hub_id) WHERE e.title LIKE :t OR h.title LIKE :t',
        [':t' => '%' . $_GET['q'] . '%']
      )
    ]
  );
}

return [
  'ul.aggregate' => [
    array_map(function($h) {
      $total = mysqly::count('entities', ['hub_id' => $h['id']]);
      return [
        'li' => [
          ['h2' => ['a' => [ h($h['title']), 'attrs' => ['href' => '/' . $h['url']]]]],
          phpy('/default/list', ['list' => mysqly::fetch('entities', ['hub_id' => $h['id'], 'order_by' => 'id DESC limit 6'])]),
          [
            'p.all' => [
              'a' => ['Всі ' . $total . ' ' . word_form($total, 'об\'єкт', 'об\'єкти', 'об\'єктів') . ' даних', 'attrs' => ['href' => '/' . $h['url']]]
            ]
          ]
        ]
      ];
    }, mysqly::fetch('hubs'))
  ]
];