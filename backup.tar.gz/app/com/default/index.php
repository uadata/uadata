<?php

if ( $_GET['q'] ) {
  return phpy(
    '/default/list',
    [
      'list' => mysqly::fetch(
        'SELECT e.* FROM entities e JOIN hubs h ON (h.id = e.hub_id) WHERE e.title LIKE :t OR h.title LIKE :t ORDER BY hub_id',
        [':t' => '%' . $_GET['q'] . '%']
      ),
      
      'split_by_hubs' => true
    ]
  );
}

return [
  ['h2.section' => 'Основні оновлення даних на ' . human_date(date('Y-m-d'), true)],
  
  'ul.entities.large' => array_map(function($r) {
    $data = entity_data($r['id'], 'm');
    
    $max = 0;
    array_walk($data, function($r) use (&$max) { $max = $max < $r['value'] ? $r['value'] : $max; });
    
    return [
      'li' . ('.ent-' . $r['id']) => [
        'a' . ($selected == $r['id'] ? '.selected' : '') => [
          'attrs' => [
            'href' => entity_url($r) . ':m',
            'title' => h($r['long_title'] ?: $r['title'])
          ],
          'h3' => [ $r['long_title'] ],
          ['b' => v(current_entity_val($r['id'])) . ($r['measure'] ? '<small>' . $r['measure'] . '</small>' : '')],
          ['small' => updated($r['id'])],
          'ul' => array_map(function($rd) use ($max) {
            return ['li' => ['i' => ['attrs' => ['style' => 'height: ' . round(100 * $rd['value'] / $max) . 'px']]]];
          }, $data)
        ]
      ]
    ];
  }, mysqly::fetch('entities', ['id' => 12])),
  
  'ul.entities.mini' => array_map(function($r) {
    $data = entity_data($r['id'], 'm');
    
    $max = 0;
    array_walk($data, function($r) use (&$max) { $max = $max < $r['value'] ? $r['value'] : $max; });
    
    return [
      'li' . ('.ent-' . $r['id']) => [
        'a' . ($selected == $r['id'] ? '.selected' : '') => [
          'attrs' => [
            'href' => entity_url($r) . ':m',
            'title' => h($r['long_title'] ?: $r['title'])
          ],
          'h3' => [ $r['title'] ],
          ['b' => v(current_entity_val($r['id'])) . ($r['measure'] ? '<small>' . $r['measure'] . '</small>' : '')],
          ['small' => updated($r['id'])],
          'ul' => array_map(function($rd) use ($max) {
            return ['li' => ['i' => ['attrs' => ['style' => 'height: ' . round(100 * $rd['value'] / $max) . 'px']]]];
          }, $data)
        ]
      ]
    ];
  }, mysqly::fetch('entities', ['id' => [2, 3, 7, 13, 14]])),
  
  '<br/>',
  
  'h2.section' => 'Усі хаби даних',
  
  'ul.hubs' => [
    array_map(function($h) {
      $total = mysqly::count('entities', ['hub_id' => $h['id']]);
      $random = mysqly::fetch('entities', ['hub_id' => $h['id'], 'order_by' => 'rand() limit 2']);
      
      return [
        'li' => [
          ['h4' => [ 'a' => [ h($h['title']), 'attrs' => ['href' => '/' . $h['url']]] ]],
          'ul' => [
            ['li' => ['a' => [$random[0]['title'], 'attrs' => ['href' => entity_url($random[0])]]]],
            ['li' => ['a' => [$random[1]['title'], 'attrs' => ['href' => entity_url($random[1])]]]],
            ['li' => ['та ще ', 'a' => [($total - 2) . ' ' . word_form($total - 2, "об'єкт", "об'єкти", "об'єктів"), 'attrs' => ['href' => '/' . $h['url']]]]],
          ],
        ]
      ];
    }, mysqly::fetch('hubs'))
  ]
];