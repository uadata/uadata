<?php return [
  'ul.entities' => array_map(function($r) use ($selected) {
    $data = entity_data($r['id']);
    
    $max = 0;
    array_walk($data, function($r) use (&$max) { $max = $max < $r['value'] ? $r['value'] : $max; });
    
    return [
      'li' => [
        'a' . ($selected == $r['id'] ? '.selected' : '') => [
          'attrs' => [
            'href' => entity_url($r),
            'title' => h($r['long_title'] ?: $r['title'])
          ],
          'h3' => [ $r['title'] ],
          ['b' => v(current_entity_val($r['id'])) . ($r['measure'] ? '<small>' . $r['measure'] . '</small>' : '')],
          ['small' => updated($r['id'])],
          'ul' => array_map(function($rd) use ($max) {
            return ['li' => ['i' => ['attrs' => ['style' => 'height: ' . round(100 * $rd['value'] / $max) . 'px']]]];
          }, $data)
        ]
      ]
    ];
  }, $list)
];