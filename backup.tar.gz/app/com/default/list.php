<?php

$index = 0;
$current_hub = $list ? mysqly::hubs_($list[$index]['hub_id']) : [];

return [
  
  $split_by_hubs && $current_hub ? [
    'h2.section' => $current_hub['title']
  ] : [],
  
  'ul.entities' . ($mini ? '.mini' : '') => array_map(function($r) use ($selected, &$current_hub, $split_by_hubs, $list, &$index) {
    $data = entity_data($r['id']);
    
    $max = 0;
    array_walk($data, function($r) use (&$max) { $max = $max < $r['value'] ? $r['value'] : $max; });
    
    $switch_hub_head = false;
    $index++;
    if ( $list[$index] && ($list[$index]['hub_id'] != $current_hub['id']) ) {
      $switch_hub_head = true;
      $current_hub = mysqly::hubs_($list[$index]['hub_id']);
    }
    
    return [
      'li' => [
        'a' . ($selected == $r['id'] ? '.selected' : '') => [
          'attrs' => [
            'href' => entity_url($r),
            'title' => h($r['long_title'] ?: $r['title'])
          ],
          'h3' => [ $r['title'] ],
          ['b' => v(current_entity_val($r['id']), true) . ($r['measure'] ? '<small>' . $r['measure'] . '</small>' : '')],
          ['small' => updated($r['id'])],
          'ul' => array_map(function($rd) use ($max) {
            return ['li' => ['i' => ['attrs' => ['style' => 'height: ' . round(100 * $rd['value'] / ($max?:1)) . 'px']]]];
          }, $data)
        ],
        
        $switch_hub_head ? ('</ul>' . '<h2 class="section">' . $current_hub['title'] . '</h2>' . '<ul class="entities">') : []
      ]
    ];
  }, $list)
];