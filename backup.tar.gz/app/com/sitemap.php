<?php

header('Content-type: application/xml');

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

foreach ( mysqly::fetch('SELECT e.*, max(rd.at) last_data_point FROM entities e JOIN ref_data rd ON (rd.entity_id = e.id) GROUP BY e.id ORDER BY last_data_point DESC') as $e ) {
  echo
    '<url>
      <loc>https://uadata.net' . entity_url( $e ) . '</loc>
      <lastmod>' . date('Y-m-d', strtotime($e['last_data_point'])) . '</lastmod>
    </url>';
}


foreach ( mysqly::fetch('SELECT * FROM ref_data WHERE status = "approved" ORDER BY at DESC') as $r ) {
  if ( !$ent = mysqly::entities_($r['entity_id']) ) {
    continue;
  }
  
  echo
    '<url>
      <loc>https://uadata.net' . entity_url( $ent ) . '/' . urlencode($r['at']) . '</loc>
      <lastmod>' . date('Y-m-d', strtotime($r['at'])) . '</lastmod>
    </url>';
}

echo '</urlset>';

exit;