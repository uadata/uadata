<?php

foreach ( mysqly::fetch('hubs') as $h ) {
  $output[] = [
    'title' => $h['title'],
    'api_url' => 'https://uadata.net/' . $h['url'] . '.json',
    'url' => 'https://uadata.net/' . $h['url']
  ];
}

header('Content-Type: application/json');
echo json_encode($output, JSON_PRETTY_PRINT);
exit;