<?php

$hub = mysqly::hubs_(['url' => trim(str_replace('.json', '', endpoint()), '/')]);
if ( $hub ) {
  foreach ( mysqly::fetch('entities', ['hub_id' => $hub['id']]) as $e ) {
    $output[] = [
      'title' => $e['long_title'] ?: $e['title'],
      'api_url' => 'https://uadata.net/' . entity_url($e) . '.json',
      'url' => 'https://uadata.net/' . entity_url($e)
    ];
  }
}

header('Content-Type: application/json');
echo json_encode($output, JSON_PRETTY_PRINT);
exit;