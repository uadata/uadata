<?php

$hub = mysqly::hubs_(['url' => trim(endpoint(), '/')]);

return [
  'h1.screen-only' => $hub['title'],
  phpy('/default/list', [
    'list' => mysqly::fetch('entities', ['hub_id' => $hub['id'], 'order_by' => 'id desc']),
  ]),
  
  [
    'p.all.back' => [
      'a' => ['&larr; всі хаби', 'attrs' => ['href' => '/']]
    ]
  ]
];