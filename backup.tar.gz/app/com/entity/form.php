<?php return form([
  'p' => 'Ви можете додати або виправити дані на цій сторінці',
  ['input.date' => ['attrs' => ['value' => h($_POST['date']) ?: date('Y-m-d H:i:s'), 'name' => 'date', 'placeholder' => 'Дата і час...']]],
  ['input.val' => ['attrs' => ['value' => h($_POST['value']), 'name' => 'value', 'placeholder' => 'Значення...']]],
  ['input' => ['attrs' => ['value' => h($_POST['ref_url']), 'name' => 'ref_url', 'placeholder' => 'Лінк на джерело...']]],
  
  ['input' => ['attrs' => ['value' => $ent['id'], 'name' => 'entity_id', 'type' => 'hidden']]],
  
  'button' => 'Відправити'
], '#contribute', '/entity/contribute');