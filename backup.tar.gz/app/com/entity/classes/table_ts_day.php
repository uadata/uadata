<?php

$props = mysqly::array('SELECT DISTINCT property FROM tables_ts WHERE entity_id = :id ORDER BY property DESC', [':id' => $ent['id']]);
$objects = mysqly::array('SELECT DISTINCT object FROM tables_ts WHERE entity_id = :id AND object IS NOT NULL', [':id' => $ent['id']]);

$prop = in_array($_GET['p'], $props) ? $_GET['p'] : $props[0];
$object = in_array($_GET['o'], $objects) ? $_GET['o'] : '';

$data = mysqly::fetch(
  'SELECT DATE(at) at, object, property, ROUND(AVG(value)) value FROM tables_ts WHERE entity_id = :id
   GROUP BY date(at), object, property
   ORDER BY at DESC',
  [':id' => $ent['id']]
);

$years = [];
foreach ( $data as $r ) {
  $y = date('Y-m-d', strtotime($r['at']));
  $years[$y] = true;
  $table[$r['object']][$r['property']][$y] += $r['value'];
  
  $ats[$y] = ['at' => $y];
}

$years = array_keys($years);
$year = in_array($_GET['y'], $years) ? $_GET['y'] : $years[0];

$stats = $table[$object][$prop];
$stats_vals = array_reverse(array_values($stats));
$stats_keys = array_reverse(array_keys($stats));
$total_value = $stats[$year];
$max_stats = max($stats_vals);



if ( $_GET['csv'] ) {
  header('Content-type: text/csv');
  header('Content-disposition: attachment; filename="uadata.csv"');
  
  echo '"","' . implode('","', $years) . '"' . "\n";
  
  foreach ( $table as $o => $row ) {
    $f = fopen('php://memory', 'r+');
    $vals = [$o ?: 'Сумарний бюджет'];
    foreach ( $years as $y ) $vals[] = $row[$prop][$y];
    fputcsv($f, $vals);
    rewind($f);
    echo rtrim(stream_get_contents($f)) . "\n";
  }
  
  exit;
}



$values = [];
foreach ( $table as $o => $r ) {
  if ( !$r[$prop] || !$o ) {
    continue;
  }
  
  $values[$o] = $r[$prop][$year];
}



arsort($values);
$max = max($values);
$total = mysqly::fetch('SELECT AVG(value) s FROM tables_ts WHERE entity_id = :id AND object IS NULL', [':id' => $ent['id']])[0]['s'];



return [
  '.chart' . ('.class-' . $ent['class']) . ('.group-' . $ent['group']) => [
    '.area' => [
      '.heading' => [

        'h1.entity-title' => [
          [$object ? $object . ' - ' : '', $ent['long_title'] ?: $ent['title'], 'small' => ' за ' . human_date($year)],
        ],
        
        $ent['help_url'] ? ['a.help' => ['?', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : [],
        
        'b.value' => [v($total_value) . $ent['measure'], 'small' => $prop],

        ($object) ? ['span.links' => [
          'Фільтр "<b>' . $object . '</b>"',
          '. ',
          'a' => ['Закрити', 'attrs' => ['href' => url(['o' => null])]]
        ]] : [],
      ],
      
      '.max' => v($max_stats),
      '.min' => $_GET['bl'] ? v($min) : 0,
      
      '.bars' => [
        
        array_map(function($v, $t) use ($max_stats, $min, $ent, $year, $prop) {
          return [
            'a.bar' . ($t == $year ? '.on' : '') => [
              'attrs' => [
                'href' => url(['y' => $t])
              ],
              'i' => ['', 'attrs' => ['style' => 'top:' . min(93, 100 - 100*($v/($max_stats?:1))) . '%']],
              'b' => [
                       'em' => v($v) . $ent['measure'] . ' ' . $prop,
                       'small' => $t . ' рік'
                     ],
            ]
          ];
        },
        $stats_vals, $stats_keys)
      ],
    ],
    
    '.legend' => phpy('/entity/legend', ['data' => array_values($ats), 'ent' => $ent]),
  ],
  
  '.table-data.ts' => [
    'table' => [
      
      ['tr' => [
        ['th' => [
          count($props) > 1 ? [
              ['select' => array_map(function($p) use ($prop, $prop1) {
                return ['option' => [$p, 'attrs' => $prop == $p ? ['selected' => 'on', 'value' => ''] : ['value' => url(['p' => $p == $prop1 ? null : $p])]]];
              }, $props)]
            ] :
            $prop,
          'attrs' => ['colspan' => 2]
        ]],
        ['th' => ''],
        ['th' => ''],
      ]],
      
      array_map(function($v, $o) use ($max, $ent, $total, $object, $prop) {
        
        if ( !$v ) return [];
        
        $portion = round(100 * $v/$max);
        $part = round(100 * $v/$total);

        return [
          'tr' . ($object == $o ? '.on' : '') => [
            ['td' => ['a' => [$o, 'attrs' => ['href' => url(['o' => $o])]]]],
            ['td.v' => (v($v) . $ent['measure'] . ($prop ? '<small>' . $prop . '</small>' : ''))],
            ['td.v' => ['small' => v($part) . '%']],
            ['td' => [
              '.hbar' => ['attrs' => ['style' => 'width: ' . $portion . '%']]
            ]]
          ]
        ];
      }, array_values($values), array_keys($values)),
      
      $prop1 ? [] : ['tr.total' => [
        ['td' => 'Вся країна'],
        ['td.v' => (v($total) . $ent['measure'] . ($prop ? ' <small>' . $prop . '</small>' : ''))],
        ['td' => ''],
        ['td' => ''],
      ]]
    ]
  ],
  
  '.meta' => [
    
    '.download' => [
      'a' => ['Завантажити CSV', 'attrs' => ['href' => url(['csv' => 1]), 'target' => '_blank']]
    ],
    
    '.api' => [
      'p' => 'Юзайте ці дані через API:',
      'pre' => ['code' => 'curl <b>https://uadata.net' . entity_url($ent) . '.json</b>'],
      ['p' => 'Доступ до API є безкоштовним і не має обмежень по частоті звернень. Але намагайтеся на спамити сервіс запитами :) та юзайте кеш.']
    ]
  ],
  
  '<br clear="both"/>',
  
  'div' => phpy('/default/list', [
    'list' => mysqly::fetch('entities', ['hub_id' => $ent['hub_id'], 'order_by' => 'id desc']),
    'selected' => $ent['id']
  ]),
];