<?php

$objects = mysqly::array('SELECT object FROM tables WHERE entity_id = :id GROUP BY object ORDER BY sum(value) DESC', [':id' => $ent['id']]);

$i = array_search($object, $objects);
$objects = array_slice($objects, max($i-1, 0), 3);

return [
  '.table-head' => [
    'h1' => [$object, 'small' => $ent['long_title'] ?: $ent['title']],
    
    'p' => [
      ['a' => [$ent['title'], 'attrs' => ['href' => entity_url($ent)]]],
      $ent['help_url'] ? ['a' => ['Джерело цих даних', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : []
    ]
  ],
  
  '.table-data' => [
    'table' => [
      array_map(function($r) {
        return [
          'tr' => [
            ['td' => $r['property']],
            ['td.v' => v($r['value'])],
          ]
        ];
      }, mysqly::fetch('tables', ['entity_id' => $ent['id'], 'object' => $object, 'order_by' => 'value DESC'])),
    ]
  ],
  
  $objects ? [
    '.related' => [
      'ul' => array_map(function($o) use ($object, $ent) {
        return [ 'li' => ['a' . ($o == $object ? '.on' : '') => [h($o), 'attrs' => ['href' => entity_url($ent) . '/' . urlencode($o)]]] ];
      }, $objects)
    ]
  ] : []
];