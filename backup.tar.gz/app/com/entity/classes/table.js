on('.table-data select', 'change', function() {
  if ( this.value ) {
    location = this.value;
  }
});