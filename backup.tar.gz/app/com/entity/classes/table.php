<?php

$props = mysqly::array('SELECT DISTINCT property FROM tables WHERE entity_id = :id', [':id' => $ent['id']]);
$prop = in_array($_GET['p'], $props) ? $_GET['p'] : $props[0];
$prop1 = in_array($_GET['p1'], $props) ? $_GET['p1'] : null;

$data = mysqly::fetch('tables', ['entity_id' => $ent['id']]);
foreach ( $data as $r ) {
  $table[$r['object']][$r['property']] = $r['value'];
}


if ( $_GET['csv'] ) {
  header('Content-type: text/csv');
  header('Content-disposition: attachment; filename="uadata.csv"');
  
  echo '"","' . implode('","', $props) . '"' . "\n";
  
  foreach ( $table as $o => $row ) {
    $f = fopen('php://memory', 'r+');
    $vals = [$o];
    foreach ( $props as $p ) $vals[] = $row[$p];
    fputcsv($f, $vals);
    rewind($f);
    echo rtrim(stream_get_contents($f)) . "\n";
  }
  
  exit;
}


$values = [];
foreach ( $table as $o => $r ) {
  if ( !$r[$prop] ) {
    continue;
  }
  
  if ( $prop1 ) {
    if ( !$r[$prop1] ) {
      continue;
    }
    
    $values[$o] = round(100 * min($r[$prop1], $r[$prop]) / max($r[$prop1], $r[$prop]), 2);
  }
  else {
    $values[$o] = $r[$prop];
  }
}

arsort($values);
$max = max($values);
$total = array_sum($values);

return [
  '.table-head' => [
    'h1' => $ent['long_title'] ?: $ent['title'],
    
    $prop1 ? '' : '',
    ($prop && $prop1) ? ['p.links' => [
        'Порівняння "<b>' . h($prop) . '</b>" та "<b>' . h($prop1) . '</b>"',
        '. ',
        'a' => ['Закрити', 'attrs' => ['href' => url(['p' => null, 'p1' => null])]]
      ]] : [],
    
    'p' => [
      $ent['help_url'] ? ['a' => ['Джерело цих даних', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : [],
    ],
    
    /*count($props) > 1 ? ['ul.props' => array_map(function($p) use ($prop) {
      return [ 'li' => [ 'a' . ($prop == $p ? '.on' : '') => [ $p, 'attrs' => [ 'href' => url(['p' => $p]) ] ] ] ];
    }, $props)] : []*/
  ],
  
  '.table-data' => [
    'table' => [
      
      ['tr' => [
        ['th' => [
          count($props) > 1 ? [
              ['select' => array_map(function($p) use ($prop, $prop1) {
                return ['option' => [$p, 'attrs' => $prop == $p ? ['selected' => 'on', 'value' => ''] : ['value' => url(['p' => $p == $prop1 ? null : $p])]]];
              }, $props)],
              ['b.vs' . ($prop1 ? '.on' : '.off') => '%'],
              ['select' . ($prop1 ? '.on' : '.off') => [
                ['option' => ['Порівняти...', 'attrs' => ['value' => url(['p1' => null])]]],
                array_map(function($p) use ($prop1) {
                return ['option' => [$p, 'attrs' => $prop1 == $p ? ['selected' => 'on', 'value' => ''] : ['value' => url(['p1' => $p])]]];
              }, array_diff($props, [$prop]))]]
            ] :
            $prop,
          'attrs' => ['colspan' => 2]
        ]],
        ['th' => ''],
      ]],
      
      array_map(function($v, $o) use ($max, $ent, $prop1) {
        
        if ( !$v ) return [];

        return [
          'tr' => [
            ['td' => ['a' => [$o, 'attrs' => ['href' => entity_url($ent) . '/' . urlencode($o)]]]],
            ['td.v' => $prop1 ? (number_format($v, 2, '.', ' ') . '<small>%</small>') : (v($v) . ($ent['measure'] ? '<small>' . $ent['measure'] . '</small>' : ''))],
            ['td' => [
              '.hbar' => ['attrs' => ['style' => 'width: ' . round(100 * $v/$max) . '%']]
            ]]
          ]
        ];
      }, array_values($values), array_keys($values)),
      
      $prop1 ? [] : ['tr.total' => [
        ['td' => 'Всього'],
        ['td.v' => (v($total) . ($ent['measure'] ? ' <small>' . $ent['measure'] . '</small>' : ''))],
        ['td' => ''],
      ]]
    ]
  ],
  
  '.meta' => [
    
    '.download' => [
      'a' => ['Завантажити CSV', 'attrs' => ['href' => url(['csv' => 1]), 'target' => '_blank']]
    ],
    
    '.api' => [
      'p' => 'Юзайте ці дані через API:',
      'pre' => ['code' => 'curl <b>https://uadata.net' . entity_url($ent) . '.json</b>'],
      ['p' => 'Доступ до API є безкоштовним і не має обмежень по частоті звернень. Але намагайтеся на спамити сервіс запитами :) та юзайте кеш.']
    ]
  ],
  
  '<br clear="both"/>',
  
  'div' => phpy('/default/list', [
    'list' => mysqly::fetch('entities', ['hub_id' => $ent['hub_id'], 'order_by' => 'id desc']),
    'selected' => $ent['id']
  ]),
];