<?php

$props = mysqly::array('SELECT DISTINCT property FROM tables WHERE entity_id = :id', [':id' => $ent['id']]);
$prop = in_array($_GET['p'], $props) ? $_GET['p'] : $props[0];

$data = mysqly::fetch('tables', ['entity_id' => $ent['id']]);
foreach ( $data as $r ) {
  $table[$r['object']][$r['property']] = $r['value'];
}

$values = [];
foreach ( $table as $o => $r ) {
  $values[$o] = $r[$prop];
}

arsort($values);
$max = max($values);
$total = array_sum($values);

return [
  '.table-head' => [
    'h1' => $ent['long_title'] ?: $ent['title'],
    
    'p' => [
      $ent['help_url'] ? ['a' => ['Джерело цих даних', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : []
    ],
    
    count($props) > 1 ? ['ul.props' => array_map(function($p) use ($prop) {
      return [ 'li' => [ 'a' . ($prop == $p ? '.on' : '') => [ $p, 'attrs' => [ 'href' => url(['p' => $p]) ] ] ] ];
    }, $props)] : []
  ],
  
  '.table-data' => [
    'table' => [
      array_map(function($v, $o) use ($max, $ent) {
        
        if ( !$v ) return [];

        return [
          'tr' => [
            ['td' => $o],
            ['td' => v($v) . ($ent['measure'] ? '<small>' . $ent['measure'] . '</small>' : '')],
            ['td' => [
              '.hbar' => ['attrs' => ['style' => 'width: ' . round(100 * $v/$max) . '%']]
            ]]
          ]
        ];
      }, array_values($values), array_keys($values)),
      
      ['tr.total' => [
        ['td' => 'Всього'],
        ['td' => v($total) . ($ent['measure'] ? ' <small>' . $ent['measure'] . '</small>' : '')],
        ['td' => ''],
      ]]
    ]
  ],
  
  '.related' => phpy('/default/list', [
    'list' => mysqly::fetch('entities', ['hub_id' => $ent['hub_id'], 'order_by' => 'id desc']),
    'selected' => $ent['id']
  ]),
];