<?php

$points = 0;
foreach ( $data as $r ) {
  $points++;
  $months[date('m', strtotime($r['at']))]++;
}

return
  $ent['class'] == 'years' ?
  [
    'ul.years' => array_map(function($r) {
      return [
        'li' => date('Y', strtotime($r['at']))
      ];
    }, $data)
  ]
  :

  [
  'ul.days' => array_map(function($r) {
    return [
      'li' => date('d', strtotime($r['at']))
    ];
  }, $data),
  
  'ul.months' => array_map(function($m, $c) use ($points) {
    return [
      'li' => [human_month($m, true), 'attrs' => ['style' => 'width:' . (100*$c/$points) . '%']]
    ];
  }, array_keys($months), $months)
];