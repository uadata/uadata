<?php

$points = 0;
foreach ( $data as $r ) {
  $points++;
  $months[date('m-y', strtotime($r['at']))]++;
}

return
  $ent['class'] == 'years' ?
  [
    'ul.years' => array_map(function($r) {
      return [
        'li' => date('Y', strtotime($r['at']))
      ];
    }, $data)
  ]
  :

  [
  'ul.days' => array_map(function($r) {
    return [
      'li' => date('d', strtotime($r['at']))
    ];
  }, $data),
  
  'ul.months' => array_map(function($my, $c) use ($points) {
    list($m, $y) = explode('-', $my);
    
    return [
      'li' => [human_month($m, true) . ($y != date('y') ? ' \'' . $y : ''), 'attrs' => ['style' => 'width:' . (100*$c/$points) . '%']]
    ];
  }, array_keys($months), $months)
];