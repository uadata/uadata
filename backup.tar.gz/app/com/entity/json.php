<?php

$ent = entity_by_endpoint(str_replace('.json', '', endpoint()));
$data = mysqly::fetch('ref_data', ['entity_id' => $ent['id'], 'status' => 'approved', 'order_by' => 'at DESC']);


$output = [
  'title' => $ent['title'],
  'url' => 'https://uadata.net' . entity_url($ent),
  'data' => []
];


foreach ( $data as $row ) {
  $output['data'][] = [
    'at' => $row['at'],
    'val' => (int)$row['value'],
    'ref' => $row['ref_url']
  ];
}


header('Content-Type: application/json');
echo json_encode($output, JSON_PRETTY_PRINT);
exit;