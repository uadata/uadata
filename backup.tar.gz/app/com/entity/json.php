<?php

$ent = entity_by_endpoint(str_replace('.json', '', endpoint()));

$output = [
  'title' => $ent['title'],
  'long_title' => $ent['long_title'],
  'url' => 'https://uadata.net' . entity_url($ent),
  'hub_api_url' => 'https://uadata.net/' . mysqly::hubs_url($ent['hub_id']) . '.json',
];

if ( $ent['help_url'] ) {
  $output['ref_url'] = $ent['help_url'];
}

$output['data'] = [];



if ( $ent['class'] == 'table_ts' ) {
  $data = mysqly::fetch('tables_ts', ['entity_id' => $ent['id'], 'order_by' => 'at desc']);
  
  foreach ( $data as $row ) {
    $output['data'][$row['object'] ?: 'Сумарний бюджет'][$row['property']][date('Y', strtotime($row['at']))] = $row['value'];
  }
}
else if ( $ent['class'] == 'table' ) {
  $data = mysqly::fetch('tables', ['entity_id' => $ent['id']]);
  
  foreach ( $data as $row ) {
    $output['data'][$row['object']][$row['property']] = $row['value'];
  }
}
else {
  $data = mysqly::fetch('ref_data', ['entity_id' => $ent['id'], 'status' => 'approved', 'order_by' => 'at DESC']);
  foreach ( $data as $row ) {
    $output['data'][] = [
      ($ent['class'] == 'years' ? 'year' : 'date') => date( $ent['class'] == 'years' ? 'Y' : 'Y-m-d', strtotime($row['at'])),
      'val' => (int)$row['value'],
      'ref' => $row['ref_url']
    ];
  }
}



header('Content-Type: application/json');
echo json_encode($output, JSON_PRETTY_PRINT);
exit;