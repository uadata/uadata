on('code', 'click', function() {
  var b = this.querySelector('b');
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(b);
  selection.removeAllRanges();
  selection.addRange(range);
});

on('.bars > .bar', 'click', function(e) {
  if ( (window.innerWidth < 800) ) {
    if ( !this.classList.contains('hovered') ) {
      remove_cls('.bars > .bar.hovered', 'hovered');
      this.classList.add('hovered');
      e.stopPropagation();
      e.preventDefault();
      return;
    }
  }
});