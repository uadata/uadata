<?php

$urls = explode('/', endpoint());
$object = urldecode($urls[3]);
$date = date('Y-m-d', strtotime($object));
$ent = entity_by_endpoint('/' . $urls[1] . '/' . $urls[2]);

if ( $ent['class'] == 'table' ) {
  return phpy('/entity/classes/table_object', ['ent' => $ent, 'object' => $object]);
}

$point = mysqly::fetch('SELECT * FROM ref_data WHERE entity_id = :id AND date(at) = :date AND status = "approved"', [
  ':id' => $ent['id'], ':date' => $date
])[0];

$data = mysqly::fetch('ref_data', ['entity_id' => $ent['id'], 'status' => 'approved', 'order_by' => 'at ASC']);
$last = $data[count($data) - 1];

if ( $last['at'] == $point['at'] ) {
  $latest = true;
}

$index = 0;
foreach ( $data as $i => $r ) {
  if ( $r['at'] == $point['at'] ) {
    $prev = $p;
    $index = $i;
    break;
  }
  
  $p = $r;
}

$start = $index - 4;
if ( $start < 0 ) {
  $start = 0;
}
$end = $start + 9;
if ( $end > count($data) ) {
  $end = count($data);
  $start = $end - 9;
  if ( $start < 0 ) {
    $start = 0;
  }
}

$data = array_slice($data, $start, 9);
$related = mysqly::fetch('entities', ['hub_id' => $ent['hub_id']]);

return [
  '.big-value' . ($latest ? '.latest' : '') => [
    '.block' => [
      'h1' => [
        h($ent['long_title'] ?: $ent['title']) . ' ',
        'small' => ($ent['type'] == 'gauge' ? 'на' : 'за') . ' ' .  ($ent['class'] == 'years' ? date('Y рік', strtotime($point['at'])) : human_date($point['at'], true))
      ],
      
      'p.context' => [
        ['a' => ['Весь графік', 'attrs' => ['href' => entity_url($ent) ]]],
        ['a' => ['Джерело даних', 'attrs' => ['href' => $point['ref_url'], 'target' => '_blank']]],
        $ent['help_url'] ? ['a' => ['Що це?', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : [],
        ['a' => [h(mysqly::hubs_title($ent['hub_id'])), 'attrs' => ['href' => '/' . mysqly::hubs_url($ent['hub_id'])]]],
        !$latest ? ['a.latest' => ['Остання точка цих даних', 'attrs' => ['href' => entity_url($ent). '/' . urlencode($last['at'])]]] : [],
      ],
      
      'ul.dates' => array_map(function($r) use ($ent, $point) {
        return [
          'li' . ($point['at'] == $r['at'] ? '.on' : '') => ['a' => [
            'span.big' => $ent['class'] == 'years' ? date('Y', strtotime($r['at'])) : date('d', strtotime($r['at'])),
            'span.small' => $ent['class'] == 'years' ? date('Y', strtotime($r['at'])) : date('d', strtotime($r['at'])),
            'attrs' => ['href' => entity_url($ent) . '/' . urlencode($r['at'])]
          ]]
        ];
      }, $data)
    ],
    

    'b.val' => [
      v($point['value']),
      'sup' . ($point['value'] < $prev['value'] ? '.down' : '') => ($point['value'] != $prev['value']) ? '<b>' . ( $point['value'] > $prev['value'] ? '+' : '&mdash;' ) . ' ' . ( v(abs( ($point['value'] - $prev['value']) )) ) . '</b> порівняно з ' . ( $ent['class'] == 'years' ? date('Y роком', strtotime($prev['at'])) : human_date($prev['at'])) : ''
    ],
    
    $related ? [
      '.related' => [
        'h4' => 'Пов\'язані дані',
        'ul' => array_map(function($e) use ($ent) {
          return [ 'li' . ($e['id'] == $ent['id'] ? '.on' : '') => ['a' => [h($e['title']), 'attrs' => ['href' => entity_url($e)]]] ];
        }, $related)
      ]
    ] : []
  ]
];