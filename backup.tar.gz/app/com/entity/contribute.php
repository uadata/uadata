<?php

if ( $_POST['entity_id'] && strtotime($_POST['date']) && $_POST['value'] && $_POST['ref_url'] ) {
  mysqly::insert('ref_data', [
    'entity_id' => $_POST['entity_id'],
    'at' => date('Y-m-d H:i:s', strtotime($_POST['date'])),
    'value' => $_POST['value'],
    'ref_url' => $_POST['ref_url']
  ]);
  
  return ['p' => 'Дякуємо, дані передано на перевірку.'];
}
else {
  return phpy('/entity/form');
}