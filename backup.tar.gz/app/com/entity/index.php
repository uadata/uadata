<?php

$endpoint = endpoint();
if ( strpos($endpoint, ':') ) {
  list($endpoint, $period) = explode(':', $endpoint);
}

$period = $period ? intval($period) : 2;

$ent = entity_by_endpoint($endpoint);
$data = entity_data($ent['id'], $period);

$max = 0;

array_walk($data, function($el) use (&$max) {
  if ( $max < $el['value'] ) $max = $el['value'];
});

return [
  '.chart' . ('.class-' . $ent['class']) . ($period > 4 ? '.dense' : '') => [
    '.area' => [
      '.heading' => [
        $ent['class'] == 'default' ? ['.date-picker' => [
          ['a' . ($period == 2 ? '.on' : '') => ['2 тижні', 'attrs' => ['href' => entity_url($ent)]]],
          ['a' . ($period == 4 ? '.on' : '') => ['4 тижні', 'attrs' => ['href' => entity_url($ent) . ':4w']]],
          ['a' . ($period == 8 ? '.on' : '') => ['8 тижнів', 'attrs' => ['href' => entity_url($ent) . ':8w']]],
          ['a' . ($period == 16 ? '.on' : '') => ['16 тижнів', 'attrs' => ['href' => entity_url($ent) . ':16w']]],
        ]] : [],
        'h1.entity-title' => [
          h($ent['long_title'] ?: $ent['title']),
        ],
        
        $ent['help_url'] ? ['a.help' => ['?', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : [],
        
        'b.value' => v(current_entity_val($ent['id'])),
        'i.upd' => updated($ent['id']),
      ],
      
      '.bars' => [
        array_map(function($row) use ($max, $ent) {
          $v = $row['value'];
          return [
            'a.bar' . ($row['undefined'] ? '.undef' : '') => [
              'attrs' => ['href' => !$row['undefined'] ? entity_url($ent) . '/' . urlencode($row['at']) : 'javascript:;'],
              'i' => ['', 'attrs' => ['style' => 'top:' . min(93, 100 - 100*$v/$max) . '%']],
              'b' => $row['undefined'] ?
                     [
                       'em' => '?',
                       'small' => $ent['class'] == 'years' ? date('Y рік', strtotime($row['at'])) : human_date($row['at'])
                     ]
                     :
                     [
                       'em' => v($v),
                       'small' => $ent['class'] == 'years' ? date('Y рік', strtotime($row['at'])) : human_date($row['at'])
                     ]
            ]
          ];
        },
        $data)
      ],
    ],
    
    '.legend' => phpy('/entity/legend', ['data' => $data, 'ent' => $ent]),
  ],
  
  '.meta' => [
    
    '#contribute' =>
      phpy('/entity/form', ['ent' => $ent]),
    
    '.api' => [
      'p' => 'Юзайте ці дані через API',
      'pre' => ['code' => 'curl <b>https://uadata.net' . endpoint() . '.json</b>'],
      ['p' => 'Доступ до API є безкоштовним і не має обмежень по частоті звернень.']
    ]
  ]
];