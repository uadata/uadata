<?php

$endpoint = endpoint();
if ( strpos($endpoint, ':') ) {
  list($endpoint, $period) = explode(':', $endpoint);
}

$period = $period ? ($period != 'm' ? intval($period) : 'm') : 2;

$ent = entity_by_endpoint($endpoint);

if ( !$ent ) {
  header('HTTP/1.0 404 Not Found');
  exit;
}

if ( $ent['class'] == 'table' ) {
  return phpy('/entity/classes/table', ['ent' => $ent]);
}

$data = entity_data($ent['id'], $_GET['csv'] ? 'm' : $period, $_GET);


if ( $_GET['csv'] ) {
  header('Content-type: text/csv');
  header('Content-disposition: attachment; filename="uadata.csv"');
  
  echo '"Date","Value"' . "\n";
  
  foreach ( $data as $row ) {
    $f = fopen('php://memory', 'r+');
    fputcsv($f, [date($ent['class'] == 'years' ? 'Y' : 'Y-m-d', strtotime($row['at'])), $row['value']]);
    rewind($f);
    echo rtrim(stream_get_contents($f)) . "\n";
  }
  
  exit;
}


if ( count($data) > 130 ) {
  $month_data = [];
  foreach ( $data as $r ) {
    $m = date('mY', strtotime($r['at']));
    $month_data[$m]['at'] = min($r['at'], $month_data[$m]['at'] ?: $r['at']);
    $month_data[$m]['at_end'] = max($r['at'], $month_data[$m]['at'] ?: $r['at']);
    $month_data[$m]['value'] += $r['value'];
    $month_data[$m]['values'] ++;
  }
  
  /*foreach ( $month_data as $m => $r ) {
    $month_data[$m]['avg'] = round($r['value'] / $r['values']);
  }*/
  
  $data = $month_data;
  $ent['group'] = 'months';
}


$cum = true;
if ( ($ent['type'] == 'counter') && !$_GET['cum'] ) {
  $cum = false;
}
else if ( ($ent['type'] == 'gauge') && $_GET['cum'] === '0' ) {
  $cum = false;
}

if ( ($ent['type'] == 'gauge') && !$cum ) {
  $pre_val = null;
  foreach ( $data as $i => $r ) {
    if ( $pre_val !== null ) {
      $data[$i]['value'] = $r['value'] - $pre_val;
    }
    else {
      $data[$i]['undefined'] = true;
      $data[$i]['value'] = 0;
    }
    
    if ( !$r['undefined'] && !$r['is_doubtful'] ) {
      $pre_val = $r['value'];
    }
  }
}
else if ( ($ent['type'] == 'counter') && $cum ) {
  $pre_val = 0;
  foreach ( $data as $i => $r ) {
    $data[$i]['value'] = $pre_val + $r['value'];
    
    if ( $data[$i]['value'] ) {
      unset($data[$i]['undefined']);
    }

    $pre_val += $r['value'];
  }
}

$max = 0;
$min = $data[0]['value'];

array_walk($data, function($el) use (&$max, &$min) {
  if ( $max < $el['value'] ) $max = $el['value'];
  if ( !$el['undefined'] && ($min > $el['value']) ) $min = $el['value'];
});

return [
  '.chart' . ('.class-' . $ent['class']) . ('.group-' . $ent['group']) . (count($data) > 40 ? '.dense' : '') => [
    '.area' => [
      '.heading' => [
        ['.control' => [
          [
            '.calc' => [
              ['a' . ($cum ? '.on' : '') => [
                ['<b></b> ', desktop_mob('накопичувальний', 'нак.')],
                'attrs' => ['href' => url(['cum' => $cum ? 0 : 1])]]
              ],
            ],
            
            '.baseline' => [
              ['a' . (!$_GET['bl'] ? '.on' : '') => [desktop_mob('від нуля', 'нуль'), 'attrs' => ['href' => url(['bl' => null])]]],
              ['a' . ($_GET['bl'] == 'min' ? '.on' : '') => [desktop_mob('від мінімума', 'мін'), 'attrs' => ['href' => url(['bl' => 'min'])]]],
            ]
          ]
        ]],
        
        ['.date-picker' => ($ent['class'] == 'default' ? [
          ['a' . ($period == 2 ? '.on' : '') => [desktop_mob('2 тижні', '2т'), 'attrs' => ['href' => entity_url($ent)]]],
          ['a' . ($period == 4 ? '.on' : '') => [desktop_mob('4 тижні', '4т'), 'attrs' => ['href' => entity_url($ent) . ':4w']]],
          ['a' . ($period == 8 ? '.on' : '') => [desktop_mob('8 тижнів', '8т'), 'attrs' => ['href' => entity_url($ent) . ':8w']]],
          ['a' . ($period == 16 ? '.on' : '') => [desktop_mob('16 тижнів', '16т'), 'attrs' => ['href' => entity_url($ent) . ':16w']]],
          ['a' . ($period == 'm' ? '.on' : '') => [desktop_mob('макс', 'м'), 'attrs' => ['href' => entity_url($ent) . ':m']]],
        ] : [])],
        
        'h1.entity-title' => [
          h($ent['long_title'] ?: $ent['title']),
        ],
        
        $ent['help_url'] ? ['a.help' => ['?', 'attrs' => ['href' => $ent['help_url'], 'target' => '_blank']]] : [],
        
        'b.value' => v(current_entity_val($ent['id'])),
        'i.upd' => updated($ent['id']),
        'a.src' => [parse_url(current_entity_src($ent['id']))['host'], 'attrs' => ['href' => current_entity_src($ent['id']), 'target' => '_blank']],
        
        ($_GET['from'] && $_GET['to']) ? ['p.links' => [
          'Показано з ' . human_date($_GET['from'], true) . ' до ' . human_date($_GET['to'], true),
          '. ',
          'a' => ['Весь графік', 'attrs' => ['href' => entity_url($ent) . ':m']]
        ]] : []
      ],
      
      '.max' => v($max),
      '.min' => $_GET['bl'] ? v($min) : 0,
      
      '.bars' => [
        
        array_map(function($row) use ($max, $min, $ent) {
          $v = $row['value'];
          
          return [
            'a.bar' . ($row['undefined'] ? '.undef' : '') . ($row['is_doubtful'] ? '.doubt' : '') => [
              'attrs' => [
                'href' => !$row['undefined'] ?
                          ( $ent['group'] == 'months' ? url(['from' => $row['at'], 'to' => $row['at_end']]) : entity_url($ent) . '/' . urlencode($row['at']))
                          :
                          'javascript:;'
              ],
              'i' => ['', 'attrs' => ['style' => 'top:' . min(93, 100 - 100*($_GET['bl'] == 'min' ? ($v-$min)/($max-$min) : $v/$max)) . '%']],
              'b' => $row['undefined'] ?
                     [
                       'em' => '?',
                       'small' => $ent['class'] == 'years' ? date('Y рік', strtotime($row['at'])) : human_date($row['at'], true)
                     ]
                     :
                     [
                       'em' => v($v),
                       'small' => $ent['class'] == 'years' ? date('Y рік', strtotime($row['at'])) : ($ent['group'] == 'months' ? human_month(date('m', strtotime($row['at'])), true) . date(' \'y', strtotime($row['at'])) : human_date($row['at'], true)),
                       ($row['is_doubtful'] ? ['.doubt' => 'ці дані мають ознаки помилки'] : '')
                     ],
            ]
          ];
        },
        $data)
      ],
    ],
    
    '.legend' => phpy('/entity/legend', ['data' => $data, 'ent' => $ent]),
  ],
  
  '.meta' => [
    
    '.download' => [
      'a' => ['Завантажити CSV', 'attrs' => ['href' => url(['csv' => 1]), 'target' => '_blank']]
    ],
    
    '.api' => [
      'p' => 'Юзайте ці дані через API (<a href="/api" target="_blank">а шо це таке?</a>):',
      'pre' => ['code' => 'curl <b>https://uadata.net' . entity_url($ent) . '.json</b>'],
      ['p' => 'Доступ до API є безкоштовним і не має обмежень по частоті звернень. Але намагайтеся на спамити сервіс запитами :) та юзайте кеш.']
    ]
  ],
  
  '<br clear="both"/>',
  
  'div' => phpy('/default/list', [
    'list' => mysqly::fetch('entities', ['hub_id' => $ent['hub_id'], 'order_by' => 'id desc']),
    'selected' => $ent['id']
  ]),
];