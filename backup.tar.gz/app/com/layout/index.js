document.addEventListener('keydown', function(e) {
  if ( e.keyCode == 27 ) {
    document.body.classList.remove('screen');
  }
});