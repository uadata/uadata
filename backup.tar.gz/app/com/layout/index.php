<?php

$uid = $_COOKIE['uid'] ?: uniqid();
setcookie('uid', $uid, time() + 60*60*24*7, '/');

return [
  ['layout' => [
    'title' => title(),
    
    'head' => [
      '<meta property="og:url" content="https://uadata.net' . endpoint() . '" />
       <meta property="og:type" content="website" />
       <meta property="og:title" content="' . title() . '" />
       <meta property="og:image" content="https://uadata.net/screen?' . round(time()/(3600)) . '&u=' . urlencode(endpoint()) . '" />'
    ],
      
    'html' => [
      
      'div' . ($_GET['screen'] ? '.screen' : '') => [
        '.head' => [
          'a.logo' => ['<b>UA</b>Дата', 'attrs' => ['href' => '/']],
          nav(),
          
          'form' => [
            'attrs' => ['action' => '/'],
            'input' => ['attrs' => [
              'name' => 'q', 'placeholder' => 'Пошук...', 'autocomplete' => 'off',
              'value' => h($_GET['q'])
            ]]
          ]
        ],
        
        '.body' => [
          phpy(),
          'br' => ['attrs' => ['clear' => 'all']]
        ],
        
        '.foot' => [
          'Зроблено в Україні в ' . date('Y') . ' році',
          ['a' => ['contact@uadata.net', 'attrs' => ['href' => 'mailto:contact@uadata.net']]],
          ['a' => ['Гітхаб', 'attrs' => ['href' => 'https://github.com/uadata', 'target' => '_blank']]],
          ['a' => ['Фейсбук', 'attrs' => ['href' => 'https://facebook.com/uadata/', 'target' => '_blank']]],
          ['a' => ['Твіттер', 'attrs' => ['href' => 'https://twitter.com/uadatahab', 'target' => '_blank']]],
          ['a.fullscreen' => ['attrs' => ['href' => 'javascript:;', 'onclick' => 'document.body.classList.add("screen"); document.body.parentNode.classList.add("screen"); document.documentElement.requestFullscreen();']]]
        ],
        
        ($_SERVER['REMOTE_ADDR'] != '93.75.252.211' ? ['script' => "fetch('https://measury.io/t/uadata?uid={$uid}')"] : '')
      ]
    ]
  ]]
];