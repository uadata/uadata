<?php

if ( $id ) {
  $hub = mysqly::hubs_($id);
}

return form([
  ($hub ? ['input' => ['attrs' => ['name' => 'id', 'type' => 'hidden', 'value' => $hub['id']]]] : []),
  ['input.row' => ['attrs' => ['name' => 'title', 'placeholder' => 'Назва...', 'value' => h($hub['title'])]]],
  ['input.row' => ['attrs' => ['name' => 'url', 'placeholder' => 'Лінк...', 'value' => h($hub['url'])]]],
  'button' => 'Зберегти'
], '#hub_edit', '/manage/hub/save');