<?php

if ( $_POST['title'] ) {
  if ( $_POST['id'] ) {
    mysqly::update('hubs', $_POST['id'], ['title' => $_POST['title']]);
  }
  else {
    mysqly::insert('hubs', ['title' => $_POST['title'], 'url' => $_POST['url']]);
  }
}

return phpy('/manage/hub/edit', ['id' => $_POST['id']]);