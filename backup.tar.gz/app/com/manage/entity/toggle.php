<?php

list($id, $date) = explode('/', $_GET['id']);
$d = mysqly::fetch('ref_data', ['entity_id' => $id, 'at' => $date])[0];
mysqly::update('ref_data', ['entity_id' => $id, 'at' => $date], ['status' => $d['status'] == 'pending' ? 'approved' : 'pending']);

die(json_encode([]));