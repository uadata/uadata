<?php

if ( $_POST['id'] && $_POST['title'] ) {
  mysqly::update('entities', $_POST['id'], [
    'title' => $_POST['title'],
    'long_title' => $_POST['long_title'],
    'help_url' => $_POST['help_url'],
    'url' => $_POST['url'],
    'class' => $_POST['class'] ?: 'default',
    'type' => $_POST['is_counter'] ? 'counter' : 'gauge',
    'measure' => $_POST['measure']
  ]);
  
  return phpy('/manage/entity/edit', ['id' => $_POST['id']]);
}
else if ( $_POST['hub_id'] && $_POST['title'] ) {
  mysqly::insert('entities', [
    'hub_id' => $_POST['hub_id'],
    'title' => $_POST['title'],
    'long_title' => $_POST['long_title'],
    'help_url' => $_POST['help_url'],
    'url' => $_POST['url'],
    'class' => $_POST['class'] ?: 'default',
    'type' => $_POST['is_counter'] ? 'counter' : 'gauge',
    'measure' => $_POST['measure']
  ]);
  return ['ok'];
}