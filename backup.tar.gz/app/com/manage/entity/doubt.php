<?php

if ( $_GET['id'] ) {
  list($id, $date) = explode('/', $_GET['id']);
  mysqly::toggle('ref_data', ['entity_id' => $id, 'at' => $date], 'is_doubtful', 1, 0);
}

die('[]');