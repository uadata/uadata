<?php

if ( $_POST['save'] ) {
  $matched = parse_import($_POST['regex'], $_POST['raw']);
  
  foreach ( $matched as $row ) {
    $year = $row[1];
    $val = $row[2];
    
    mysqly::insert('ref_data', [
      'entity_id' => $_POST['id'],
      'at' => "{$year}-01-01 00:00:00",
      'value' => $val,
      'ref_url' => $_POST['ref_url'],
      'status' => 'approved'
    ]);
  }
  
  return ['Збережено'];
}

return phpy('/manage/entity/import', $_POST);