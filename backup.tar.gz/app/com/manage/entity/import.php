<?php

if ( $_POST['regex'] && $_POST['raw'] ) {
  $matched = parse_import($_POST['regex'], $_POST['raw']);
}

return form([
  ['input' => ['attrs' => ['name' => 'id', 'type' => 'hidden', 'value' => $id]]],
  ['input.row' => ['attrs' => ['name' => 'regex', 'value' => h($regex), 'placeholder' => 'Регулярка...']]],
  ['textarea.row' => [h($raw), 'attrs' => ['name' => 'raw']]],
  
  $matched ? [
    ['input.row' => ['attrs' => ['name' => 'ref_url', 'value' => h($ref_url), 'placeholder' => 'Лінк на джерело...']]],
    
    'table.row.mini' => array_map(function($m) {
      return [
          'tr' => '<td>' . implode('</td><td> &mdash;&gt; </td><td>', $m) . '</td>'
        ];
      }, $matched),
      '.row' => [
        ['input' => ['attrs' => ['type' => 'checkbox', 'name' => 'save', 'value' => 1]]],
        'Зберегти в базу'
      ]
  ] : [],
  
  'button' => 'Додати'
], '#import', '/manage/entity/parse');