function status_toggle() {
  var classes = ['pending', 'approved'];
  var assign = this.classList.contains(classes[0]) ? classes[1] : classes[0];
  var e = this;
  
  classes.forEach(function(c) { e.classList.remove(c); });
  this.classList.add(assign);
  this.innerText = assign;
  
  fetch('/manage/entity/toggle?id=' + this.dataset.id);
}

function drop_data() {
  if ( !confirm('Delete this data item?') ) return false;
  
  fetch('/manage/entity/drop?id=' + this.dataset.id);
  this.parentNode.parentNode.remove();
}



on('input[name=val]', 'keydown', function(e) {
  if ( e.keyCode == 13 ) {
    fetch('/manage/entity/val?id=' + this.dataset.id + '&val=' + this.value);
    this.blur();
  }
});