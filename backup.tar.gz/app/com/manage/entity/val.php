<?php

list($id, $date) = explode('/', $_GET['id']);
mysqly::update('ref_data', ['entity_id' => $id, 'at' => $date], ['value' => $_GET['val']]);

die(json_encode([]));