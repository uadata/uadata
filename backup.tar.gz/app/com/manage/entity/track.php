<?php

if ( $_POST['id'] && strtotime($_POST['at']) && array_key_exists('value', $_POST) && $_POST['ref_url'] ) {
  mysqly::insert('ref_data', [
    'entity_id' => $_POST['id'],
    'at' => $_POST['at'],
    'value' => $_POST['value'],
    'ref_url' => $_POST['ref_url'],
    'status' => 'approved'
  ]);
  
  return ['p' => 'Рясно дякую, дані збережено.'];
}
else {
  return phpy('/manage/entity/data');
}