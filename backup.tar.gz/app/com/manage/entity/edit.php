<?php

if ( $id ) {
  $ent = mysqly::entities_($id);
}

return form([
  $ent['id'] ? ['input' => ['attrs' => ['name' => 'id', 'type' => 'hidden', 'value' => $ent['id']]]] : [],
  $_GET['hub_id'] ? ['input' => ['attrs' => ['name' => 'hub_id', 'type' => 'hidden', 'value' => $_GET['hub_id']]]] : [],
  ['input.row' => ['attrs' => ['name' => 'title', 'placeholder' => 'Назва', 'value' => h($ent['title'])]]],
  ['input.row' => ['attrs' => ['name' => 'long_title', 'placeholder' => 'Повна назва', 'value' => h($ent['long_title'])]]],
  ['input.row' => ['attrs' => ['name' => 'url', 'placeholder' => 'Лінк англійською', 'value' => h($ent['url'])]]],
  ['input.row' => ['attrs' => ['name' => 'help_url', 'placeholder' => 'Лінк на опис цих даних, якщо є' , 'value' => h($ent['help_url'])]]],
  ['input.row' => ['attrs' => ['name' => 'measure', 'placeholder' => 'Метрика' , 'value' => h($ent['measure'])]]],
  ['.row' => [
    'label' => [
      'input' => ['attrs' => ['name' => 'is_counter', 'type' => 'checkbox' , 'value' => '1', ($ent['type'] == 'counter' ? 'checked' : '') => ($ent['type'] == 'counter' ? '1' : '')]],
      'Це є лічільник'
    ]
  ]],
  ['.row' => [
      array_map(
        function($c) use ($ent) {
          return [
            'label' => [
              'input' => ['attrs' => ['name' => 'class', 'type' => 'radio' , 'value' => $c, ($ent['class'] == $c ? 'checked' : '') => '']],
              ' ',
              $c
            ]
          ];
        },
        ['default', 'years', 'table', 'table_ts']
      )
  ]],
  'button' => 'Зберегти'
], '#hub_edit', '/manage/entity/save');