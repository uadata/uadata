<?php

$ent = mysqly::entities_($id);

return form([
  ['input' => ['attrs' => ['name' => 'id', 'type' => 'hidden', 'value' => $ent['id']]]],
  ['input' => ['attrs' => ['name' => 'at', 'value' => date('Y-m-d H:i:s')]]],
  ['input' => ['attrs' => ['name' => 'value', 'placeholder' => 'Значення...']]],
  ['input' => ['attrs' => ['name' => 'ref_url', 'placeholder' => 'Лінк на джерело']]],
  'button' => 'Додати'
], '#add_data', '/manage/entity/track');