<?php

if ( $_GET['id'] ) {
  list($id, $date) = explode('/', $_GET['id']);
  mysqly::remove('ref_data', ['entity_id' => $id, 'at' => $date])[0];
}

die(json_encode([]));