<?php

$ent = mysqly::entities_($_GET['id']);

return [
  '#hub_edit' => [phpy('/manage/entity/edit', ['id' => $ent['id']]), 'attrs' => ['class' => 'block']],
  
  '#add_data' => [phpy('/manage/entity/data', ['id' => $ent['id']]), 'attrs' => ['class' => 'block']],
  
  '.table' => [
    'table' => [
      ['tr' => [
        ['th' => ['Дата']],
        ['th' => ['Значення']],
        ['th' => ['Джерело']],
        ['th' => ['Статус']],
        ['th' => ['']],
      ]],
      array_map(function($r) {
        return [
          'tr' => [
            ['td' => $r['at']],
            ['td' => ['input.num' => ['attrs' => ['name' => 'val', 'data-id' => $r['entity_id'] . '/' . $r['at'], 'value' => $r['value']]]]],
            ['td' => ['a' => ['Відкрити', 'attrs' => ['href' => $r['ref_url']]]]],
            ['td' => ['jsa' => ['status_toggle' => $r['status'], 'attrs' => ['class' => 'badge ' . $r['status'], 'data-id' => $r['entity_id'] . '/' . $r['at']]]]],
            ['td' => [
              ['jsa' => ['drop_data' => 'drop', 'attrs' => ['class' => 'badge del', 'data-id' => $r['entity_id'] . '/' . $r['at']]]]
            ]]
          ]
        ];
      }, mysqly::fetch('ref_data', ['entity_id' => $ent['id'], 'order_by' => 'at DESC']))
    ]
  ],
  
  '#import' => [phpy('/manage/entity/import', ['id' => $ent['id']]), 'attrs' => ['class' => 'block']],
];