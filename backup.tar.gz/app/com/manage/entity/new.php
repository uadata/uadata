<?php

return [
  '#hub_edit' => [phpy('/manage/entity/edit', ['hub_id' => $_GET['hub_id']]), 'attrs' => ['class' => 'block']],
];