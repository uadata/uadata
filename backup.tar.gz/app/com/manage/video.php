<?php

$v = '/var/www/videos/' . trim($_GET['v'], '/.');

header('Content-type: video/mp4');
header('Content-disposition: attachment; filename="' . $_GET['v'] . '"');
readfile($v);

exit;