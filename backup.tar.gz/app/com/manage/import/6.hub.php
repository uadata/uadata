<?php

$rates = json_decode($_POST['post'], 1);

if ( $rates ) {
  
  $url = $_POST['url'];
  
  if ( $ts = strtotime(trim($_POST['date'])) ) {
    $at = date('Y-m-d', $ts);
    
    $map = [
      'USD' => 31,
      'EUR' => 32,
      'RUB' => 33,
    ];
    
    foreach ( $rates as $c => $v ) {
      if ( mysqly::fetch('ref_data', ['at' => $at, 'entity_id' => $map[$c]]) ) {
        continue;
      }
      
      mysqly::insert('ref_data', [
        'ref_url' => $url,
        'entity_id' => $map[$c],
        'value' => $v,
        'at' => $at,
        'status' => 'approved'
      ]);
    }
  }
}

return [];