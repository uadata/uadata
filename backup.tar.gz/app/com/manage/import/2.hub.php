<?php

# error_log(print_r($_POST, 1));

if ( isset($_SERVER['HTTP_ORIGIN']) ) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
}

function m($reg, $post) {
  preg_match($reg, $post, $m);
  return $m;
}

return [];

