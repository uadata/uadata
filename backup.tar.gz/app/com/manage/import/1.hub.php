<?php

# error_log(print_r($_POST, 1));

if ( isset($_SERVER['HTTP_ORIGIN']) ) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
}

function m($reg, $post) {
  preg_match($reg, $post, $m);
  return $m;
}

if ( $_POST['url'] && $_POST['post'] ) {
  $post = $_POST['post'];
  $post = str_replace('тисяч', '000', $post);
  $post = preg_replace('/([0-9]+) ([0-9]+)/', '$1$2', $post);
  
  $dt = m('/з 24.02 по ([0-9]+)\.([0-9]+) /misu', $post);
  if ( !$dt[1] || !$dt[2] ) {
    return 'Я не зміг знайти дату публікації';
  }
  
  $date = strtotime(date('Y') . '-' . $dt[2] . '-' . $dt[1] . ' 10:00:00');
  
  $map = [
    'особов[^0-9]*?([0-9]+)[^0-9]+' => 12,
    'броньован.*?([0-9]+)[^0-9]+' => 1,
    'танк.*?([0-9]+)[^0-9]+' => 3,
    'артилерійськ.+?([0-9]+)[^0-9]+' => 4,
    'РСЗВ.+?([0-9]+)[^0-9]+' => 5,
    'засоби ППО.+?([0-9]+)[^0-9]+' => 6,
    'літак.*?([0-9]+)[^0-9]+' => 2,
    'гелікоптер.*?([0-9]+)[^0-9]+' => 7,
    'автомобіль.*?([0-9]+)[^0-9]+' => 8,
    'корабл.*?([0-9]+)[^0-9]+' => 9,
    'цистерн.*?([0-9]+)[^0-9]+' => 10,
    'БПЛА.*?([0-9]+)[^0-9]+' => 11,
  ];
  
  $html = '<pre>' . $post;
  foreach ( $map as $reg => $entity_id ) {
    $v = m('/' . $reg . '/mui', $post)[1];
    $v = str_replace(' ', '', $v);
    
    #$v = m('/' . $reg . '/mui', $post);
    #$html .= "\n\n" . print_r($v, 1);
    #continue;
    
    if ( $v ) {
      $exists = mysqly::fetch('SELECT * FROM ref_data WHERE entity_id = :id AND date(at) = :date', [
        ':id' => $entity_id,
        ':date' => date('Y-m-d', $date)
      ]);
      
      if ( $exists ) {
        mysqly::exec('DELETE FROM ref_data WHERE entity_id = :id AND date(at) = :date', [
          ':id' => $entity_id,
          ':date' => date('Y-m-d', $date)
        ]);
      }
      
      mysqly::insert('ref_data', [
        'entity_id' => $entity_id,
        'at' => date('Y-m-d H:i:s', $date),
        'value' => $v,
        'ref_url' => $_POST['url'],
        'status' => 'approved'
      ]);
    }
  }
  
  # return $html;
  
  return ['p' => 'Оброблено'];
}


return form([
  'input.row' => ['attrs' => ['name' => 'url', 'placeholder' => 'Лінк на новину від МО']],
  'textarea.row' => ['attrs' => ['name' => 'post', 'placeholder' => 'Текст новини']],
  'button' => 'Обробити'
], '#import', '/manage/import/1.hub');