<?php return [
  '#hub_edit' => [phpy('/manage/hub/edit'), 'attrs' => ['class' => 'block']],
  
  '.table' => [
    'table' => [
      ['tr' => [
        ['th' => ['']],
        ['th' => ['Хаб']],
        ['th' => ['URL']],
        ['th' => ['']],
      ]],
      array_map(function($r) {
        return [
          'tr' => [
            ['td' => $r['id']],
            ['td' => ['a' => [$r['title'], 'attrs' => ['href' => '/manage/hub?id=' . $r['id']]]]],
            ['td' => ['a' => [$r['url'], 'attrs' => ['href' => '/' . $r['url']]]]],
            ['td' => []]
          ]
        ];
      }, mysqly::fetch('hubs'))
    ]
  ],
  
  ['.table' => [
    'table' => [
      array_map(function($v) {
        list($h, $e) = explode('_', basename(str_replace('.mp4','', $v)));
        
        $hub = mysqly::hubs_(['url' => $h]);
        $ent = mysqly::entities_(['hub_id' => $hub['id'], 'url' => $e]);
        $last = latest_entity_entry($ent['id']);
        
        return [
          'tr' => [
            ['td' => [
              'h4' => [
                date('Y-m-d H:i', filectime($v)) . ' / ',
                'a' => [basename($v), 'attrs' => ['href' => '/manage/video?v=' . basename($v)]]
              ],
              '<br/>',
              'input' => ['attrs' => [
                'value' => human_date($last['at'], true) . ' - ' . $ent['title'] . ' / ' . $hub['title']
              ]],
              'textarea' => [
                $ent['long_title'] . "\n",
                'https://uadata.net' . entity_url($ent) . "\n",
                'Оновлено ' . human_date($last['at'], true) . "\n",
                '#війна #україна #втратирф #зсу #статистика'
              ],
              ['<br/>', '<br/>'],
            ]]
          ]
        ];
      }, glob('/var/www/videos/*'))
    ]
  ]]
];