<?php return [
  '#hub_edit' => [phpy('/manage/hub/edit'), 'attrs' => ['class' => 'block']],
  
  '.table' => [
    'table' => [
      ['tr' => [
        ['th' => ['']],
        ['th' => ['Хаб']],
        ['th' => ['URL']],
        ['th' => ['']],
      ]],
      array_map(function($r) {
        return [
          'tr' => [
            ['td' => $r['id']],
            ['td' => ['a' => [$r['title'], 'attrs' => ['href' => '/manage/hub?id=' . $r['id']]]]],
            ['td' => ['a' => [$r['url'], 'attrs' => ['href' => '/' . $r['url']]]]],
            ['td' => []]
          ]
        ];
      }, mysqly::fetch('hubs'))
    ]
  ]
];