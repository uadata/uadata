<?php

$hub = mysqly::hubs_($_GET['id']);
$import_file = __DIR__ . '/import/' . $hub['id'] . '.hub.php';

return [
  '#hub_edit' => [phpy('/manage/hub/edit', ['id' => $_GET['id']]), 'attrs' => ['class' => 'block']],
  
  '.table' => [
    'table' => [
      ['tr' => [
        ['th' => ['']],
        ['th' => [
          'Об\'єкт ',
          ['a.button' => ['Додати', 'attrs' => ['href' => '/manage/entity/new?hub_id=' . $_GET['id']]]]
        ]],
        ['th' => ['URL']],
        ['th' => ['']],
      ]],
      array_map(function($r) {
        return [
          'tr' => [
            ['td' => $r['id']],
            ['td' => ['a' => [$r['title'], 'attrs' => ['href' => '/manage/entity?id=' . $r['id']]]]],
            ['td' => ['a' => [$r['url'], 'attrs' => ['href' => entity_url($r)]]]],
            ['td' => []]
          ]
        ];
      }, mysqly::fetch('entities', ['hub_id' => $hub['id']]))
    ]
  ],
  
  '#import' => [is_file($import_file) ? include $import_file : [], 'attrs' => ['class' => 'block']]
];